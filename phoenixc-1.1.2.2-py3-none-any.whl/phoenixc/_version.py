"""
-*- coding: utf-8 -*-
@Time : 2024
"""
version = "1.1.2.2"

def get_versions():
    return version