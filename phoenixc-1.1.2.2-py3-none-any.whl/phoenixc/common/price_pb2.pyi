from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqCurrentSnapshotParams(_message.Message):
    __slots__ = ["unified_code", "market"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ...) -> None: ...

class ReqPriceParams(_message.Message):
    __slots__ = ["unified_code", "market", "start_date", "end_date", "frequency", "adjust_type", "skip_suspended", "time_slice"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    ADJUST_TYPE_FIELD_NUMBER: _ClassVar[int]
    SKIP_SUSPENDED_FIELD_NUMBER: _ClassVar[int]
    TIME_SLICE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    start_date: str
    end_date: str
    frequency: str
    adjust_type: str
    skip_suspended: bool
    time_slice: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., frequency: _Optional[str] = ..., adjust_type: _Optional[str] = ..., skip_suspended: bool = ..., time_slice: _Optional[str] = ...) -> None: ...

class ReqCurrentMinuteParams(_message.Message):
    __slots__ = ["unified_code"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    def __init__(self, unified_code: _Optional[str] = ...) -> None: ...

class CurrentMinuteData(_message.Message):
    __slots__ = ["unified_code", "data_time", "open", "high", "low", "close", "volume", "turnover", "iopv"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    HIGH_FIELD_NUMBER: _ClassVar[int]
    LOW_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    TURNOVER_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    data_time: _timestamp_pb2.Timestamp
    open: float
    high: float
    low: float
    close: float
    volume: float
    turnover: float
    iopv: float
    def __init__(self, unified_code: _Optional[str] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., open: _Optional[float] = ..., high: _Optional[float] = ..., low: _Optional[float] = ..., close: _Optional[float] = ..., volume: _Optional[float] = ..., turnover: _Optional[float] = ..., iopv: _Optional[float] = ...) -> None: ...

class TickData(_message.Message):
    __slots__ = ["unified_code", "data_time", "open", "close", "high", "low", "last", "limit_up", "limit_down", "total_turnover", "volume", "pre_close", "open_interest", "asks", "ask_vols", "bids", "bid_vols", "change_rate", "trading_date", "pre_settlement", "iopv", "pre_iopv", "settlement"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    HIGH_FIELD_NUMBER: _ClassVar[int]
    LOW_FIELD_NUMBER: _ClassVar[int]
    LAST_FIELD_NUMBER: _ClassVar[int]
    LIMIT_UP_FIELD_NUMBER: _ClassVar[int]
    LIMIT_DOWN_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TURNOVER_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_FIELD_NUMBER: _ClassVar[int]
    OPEN_INTEREST_FIELD_NUMBER: _ClassVar[int]
    ASKS_FIELD_NUMBER: _ClassVar[int]
    ASK_VOLS_FIELD_NUMBER: _ClassVar[int]
    BIDS_FIELD_NUMBER: _ClassVar[int]
    BID_VOLS_FIELD_NUMBER: _ClassVar[int]
    CHANGE_RATE_FIELD_NUMBER: _ClassVar[int]
    TRADING_DATE_FIELD_NUMBER: _ClassVar[int]
    PRE_SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    PRE_IOPV_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    data_time: _timestamp_pb2.Timestamp
    open: float
    close: float
    high: float
    low: float
    last: float
    limit_up: float
    limit_down: float
    total_turnover: float
    volume: int
    pre_close: float
    open_interest: float
    asks: _containers.RepeatedScalarFieldContainer[float]
    ask_vols: _containers.RepeatedScalarFieldContainer[int]
    bids: _containers.RepeatedScalarFieldContainer[float]
    bid_vols: _containers.RepeatedScalarFieldContainer[int]
    change_rate: float
    trading_date: _timestamp_pb2.Timestamp
    pre_settlement: float
    iopv: float
    pre_iopv: float
    settlement: float
    def __init__(self, unified_code: _Optional[str] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., open: _Optional[float] = ..., close: _Optional[float] = ..., high: _Optional[float] = ..., low: _Optional[float] = ..., last: _Optional[float] = ..., limit_up: _Optional[float] = ..., limit_down: _Optional[float] = ..., total_turnover: _Optional[float] = ..., volume: _Optional[int] = ..., pre_close: _Optional[float] = ..., open_interest: _Optional[float] = ..., asks: _Optional[_Iterable[float]] = ..., ask_vols: _Optional[_Iterable[int]] = ..., bids: _Optional[_Iterable[float]] = ..., bid_vols: _Optional[_Iterable[int]] = ..., change_rate: _Optional[float] = ..., trading_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., pre_settlement: _Optional[float] = ..., iopv: _Optional[float] = ..., pre_iopv: _Optional[float] = ..., settlement: _Optional[float] = ...) -> None: ...

class CurrentSnapshotTickData(_message.Message):
    __slots__ = ["unified_code", "data_time", "open", "close", "high", "low", "last", "limit_up", "limit_down", "total_turnover", "volume", "pre_close", "open_interest", "asks", "ask_vols", "bids", "bid_vols", "settlement", "pre_iopv", "pre_settlement", "iopv", "change_rate", "status"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    HIGH_FIELD_NUMBER: _ClassVar[int]
    LOW_FIELD_NUMBER: _ClassVar[int]
    LAST_FIELD_NUMBER: _ClassVar[int]
    LIMIT_UP_FIELD_NUMBER: _ClassVar[int]
    LIMIT_DOWN_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TURNOVER_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_FIELD_NUMBER: _ClassVar[int]
    OPEN_INTEREST_FIELD_NUMBER: _ClassVar[int]
    ASKS_FIELD_NUMBER: _ClassVar[int]
    ASK_VOLS_FIELD_NUMBER: _ClassVar[int]
    BIDS_FIELD_NUMBER: _ClassVar[int]
    BID_VOLS_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    PRE_IOPV_FIELD_NUMBER: _ClassVar[int]
    PRE_SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    CHANGE_RATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    data_time: _timestamp_pb2.Timestamp
    open: float
    close: float
    high: float
    low: float
    last: float
    limit_up: float
    limit_down: float
    total_turnover: float
    volume: int
    pre_close: float
    open_interest: float
    asks: _containers.RepeatedScalarFieldContainer[float]
    ask_vols: _containers.RepeatedScalarFieldContainer[int]
    bids: _containers.RepeatedScalarFieldContainer[float]
    bid_vols: _containers.RepeatedScalarFieldContainer[int]
    settlement: float
    pre_iopv: float
    pre_settlement: float
    iopv: float
    change_rate: float
    status: str
    def __init__(self, unified_code: _Optional[str] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., open: _Optional[float] = ..., close: _Optional[float] = ..., high: _Optional[float] = ..., low: _Optional[float] = ..., last: _Optional[float] = ..., limit_up: _Optional[float] = ..., limit_down: _Optional[float] = ..., total_turnover: _Optional[float] = ..., volume: _Optional[int] = ..., pre_close: _Optional[float] = ..., open_interest: _Optional[float] = ..., asks: _Optional[_Iterable[float]] = ..., ask_vols: _Optional[_Iterable[int]] = ..., bids: _Optional[_Iterable[float]] = ..., bid_vols: _Optional[_Iterable[int]] = ..., settlement: _Optional[float] = ..., pre_iopv: _Optional[float] = ..., pre_settlement: _Optional[float] = ..., iopv: _Optional[float] = ..., change_rate: _Optional[float] = ..., status: _Optional[str] = ...) -> None: ...

class PriceBarData(_message.Message):
    __slots__ = ["unified_code", "data_time", "open", "close", "high", "low", "limit_up", "limit_down", "total_turnover", "volume", "num_trades", "pre_close", "settlement", "pre_settlement", "open_interest", "trading_date", "dominant_id", "strike_price", "contract_multiplier", "iopv"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    HIGH_FIELD_NUMBER: _ClassVar[int]
    LOW_FIELD_NUMBER: _ClassVar[int]
    LIMIT_UP_FIELD_NUMBER: _ClassVar[int]
    LIMIT_DOWN_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TURNOVER_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    NUM_TRADES_FIELD_NUMBER: _ClassVar[int]
    PRE_CLOSE_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    PRE_SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    OPEN_INTEREST_FIELD_NUMBER: _ClassVar[int]
    TRADING_DATE_FIELD_NUMBER: _ClassVar[int]
    DOMINANT_ID_FIELD_NUMBER: _ClassVar[int]
    STRIKE_PRICE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    IOPV_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    data_time: _timestamp_pb2.Timestamp
    open: float
    close: float
    high: float
    low: float
    limit_up: float
    limit_down: float
    total_turnover: float
    volume: int
    num_trades: int
    pre_close: float
    settlement: float
    pre_settlement: float
    open_interest: int
    trading_date: _timestamp_pb2.Timestamp
    dominant_id: str
    strike_price: float
    contract_multiplier: float
    iopv: float
    def __init__(self, unified_code: _Optional[str] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., open: _Optional[float] = ..., close: _Optional[float] = ..., high: _Optional[float] = ..., low: _Optional[float] = ..., limit_up: _Optional[float] = ..., limit_down: _Optional[float] = ..., total_turnover: _Optional[float] = ..., volume: _Optional[int] = ..., num_trades: _Optional[int] = ..., pre_close: _Optional[float] = ..., settlement: _Optional[float] = ..., pre_settlement: _Optional[float] = ..., open_interest: _Optional[int] = ..., trading_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., dominant_id: _Optional[str] = ..., strike_price: _Optional[float] = ..., contract_multiplier: _Optional[float] = ..., iopv: _Optional[float] = ...) -> None: ...

class RespCurrentSnapshot(_message.Message):
    __slots__ = ["current_snapshot_list"]
    CURRENT_SNAPSHOT_LIST_FIELD_NUMBER: _ClassVar[int]
    current_snapshot_list: _containers.RepeatedCompositeFieldContainer[CurrentSnapshotTickData]
    def __init__(self, current_snapshot_list: _Optional[_Iterable[_Union[CurrentSnapshotTickData, _Mapping]]] = ...) -> None: ...

class RespPrice(_message.Message):
    __slots__ = ["tick_list", "bar_data_list"]
    TICK_LIST_FIELD_NUMBER: _ClassVar[int]
    BAR_DATA_LIST_FIELD_NUMBER: _ClassVar[int]
    tick_list: _containers.RepeatedCompositeFieldContainer[TickData]
    bar_data_list: _containers.RepeatedCompositeFieldContainer[PriceBarData]
    def __init__(self, tick_list: _Optional[_Iterable[_Union[TickData, _Mapping]]] = ..., bar_data_list: _Optional[_Iterable[_Union[PriceBarData, _Mapping]]] = ...) -> None: ...

class RespCurrentMinute(_message.Message):
    __slots__ = ["current_minute_list"]
    CURRENT_MINUTE_LIST_FIELD_NUMBER: _ClassVar[int]
    current_minute_list: _containers.RepeatedCompositeFieldContainer[CurrentMinuteData]
    def __init__(self, current_minute_list: _Optional[_Iterable[_Union[CurrentMinuteData, _Mapping]]] = ...) -> None: ...

class ReqGetExFactorParam(_message.Message):
    __slots__ = ["unified_code", "market", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class ExFactor(_message.Message):
    __slots__ = ["unified_code", "ex_date", "announcement_date", "ex_end_date", "ex_factor", "ex_cum_factor"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    EX_DATE_FIELD_NUMBER: _ClassVar[int]
    ANNOUNCEMENT_DATE_FIELD_NUMBER: _ClassVar[int]
    EX_END_DATE_FIELD_NUMBER: _ClassVar[int]
    EX_FACTOR_FIELD_NUMBER: _ClassVar[int]
    EX_CUM_FACTOR_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    ex_date: _timestamp_pb2.Timestamp
    announcement_date: _timestamp_pb2.Timestamp
    ex_end_date: _timestamp_pb2.Timestamp
    ex_factor: float
    ex_cum_factor: float
    def __init__(self, unified_code: _Optional[str] = ..., ex_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., announcement_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., ex_end_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., ex_factor: _Optional[float] = ..., ex_cum_factor: _Optional[float] = ...) -> None: ...

class RespGetExFactor(_message.Message):
    __slots__ = ["ex_factor_list"]
    EX_FACTOR_LIST_FIELD_NUMBER: _ClassVar[int]
    ex_factor_list: _containers.RepeatedCompositeFieldContainer[ExFactor]
    def __init__(self, ex_factor_list: _Optional[_Iterable[_Union[ExFactor, _Mapping]]] = ...) -> None: ...

class ReqGetDividendParam(_message.Message):
    __slots__ = ["unified_code", "market", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class DividendInfo(_message.Message):
    __slots__ = ["unified_code", "declaration_announcement_date", "book_closure_date", "ex_dividend_date", "payable_date", "dividend_cash_before_tax", "round_lot", "advance_date", "quarter"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DECLARATION_ANNOUNCEMENT_DATE_FIELD_NUMBER: _ClassVar[int]
    BOOK_CLOSURE_DATE_FIELD_NUMBER: _ClassVar[int]
    EX_DIVIDEND_DATE_FIELD_NUMBER: _ClassVar[int]
    PAYABLE_DATE_FIELD_NUMBER: _ClassVar[int]
    DIVIDEND_CASH_BEFORE_TAX_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    ADVANCE_DATE_FIELD_NUMBER: _ClassVar[int]
    QUARTER_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    declaration_announcement_date: _timestamp_pb2.Timestamp
    book_closure_date: _timestamp_pb2.Timestamp
    ex_dividend_date: _timestamp_pb2.Timestamp
    payable_date: _timestamp_pb2.Timestamp
    dividend_cash_before_tax: float
    round_lot: int
    advance_date: _timestamp_pb2.Timestamp
    quarter: str
    def __init__(self, unified_code: _Optional[str] = ..., declaration_announcement_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., book_closure_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., ex_dividend_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., payable_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., dividend_cash_before_tax: _Optional[float] = ..., round_lot: _Optional[int] = ..., advance_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., quarter: _Optional[str] = ...) -> None: ...

class RespGetDividend(_message.Message):
    __slots__ = ["dividend_list"]
    DIVIDEND_LIST_FIELD_NUMBER: _ClassVar[int]
    dividend_list: _containers.RepeatedCompositeFieldContainer[DividendInfo]
    def __init__(self, dividend_list: _Optional[_Iterable[_Union[DividendInfo, _Mapping]]] = ...) -> None: ...

class ReqGetSplitParam(_message.Message):
    __slots__ = ["unified_code", "market", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class SplitInfo(_message.Message):
    __slots__ = ["unified_code", "ex_dividend_date", "book_closure_date", "payable_date", "split_coefficient_from", "split_coefficient_to", "cum_factor"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    EX_DIVIDEND_DATE_FIELD_NUMBER: _ClassVar[int]
    BOOK_CLOSURE_DATE_FIELD_NUMBER: _ClassVar[int]
    PAYABLE_DATE_FIELD_NUMBER: _ClassVar[int]
    SPLIT_COEFFICIENT_FROM_FIELD_NUMBER: _ClassVar[int]
    SPLIT_COEFFICIENT_TO_FIELD_NUMBER: _ClassVar[int]
    CUM_FACTOR_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    ex_dividend_date: _timestamp_pb2.Timestamp
    book_closure_date: _timestamp_pb2.Timestamp
    payable_date: _timestamp_pb2.Timestamp
    split_coefficient_from: float
    split_coefficient_to: float
    cum_factor: float
    def __init__(self, unified_code: _Optional[str] = ..., ex_dividend_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., book_closure_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., payable_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., split_coefficient_from: _Optional[float] = ..., split_coefficient_to: _Optional[float] = ..., cum_factor: _Optional[float] = ...) -> None: ...

class RespGetSplit(_message.Message):
    __slots__ = ["split_list"]
    SPLIT_LIST_FIELD_NUMBER: _ClassVar[int]
    split_list: _containers.RepeatedCompositeFieldContainer[SplitInfo]
    def __init__(self, split_list: _Optional[_Iterable[_Union[SplitInfo, _Mapping]]] = ...) -> None: ...

class ReqGetExchangeRateParam(_message.Message):
    __slots__ = ["start_date", "end_date"]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    start_date: str
    end_date: str
    def __init__(self, start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class ExchangeRate(_message.Message):
    __slots__ = ["trade_date", "currency_pair", "bid_referrence_rate", "ask_referrence_rate", "middle_referrence_rate", "bid_settlement_rate_sh", "ask_settlement_rate_sh", "bid_settlement_rate_sz", "ask_settlement_rate_sz"]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_PAIR_FIELD_NUMBER: _ClassVar[int]
    BID_REFERRENCE_RATE_FIELD_NUMBER: _ClassVar[int]
    ASK_REFERRENCE_RATE_FIELD_NUMBER: _ClassVar[int]
    MIDDLE_REFERRENCE_RATE_FIELD_NUMBER: _ClassVar[int]
    BID_SETTLEMENT_RATE_SH_FIELD_NUMBER: _ClassVar[int]
    ASK_SETTLEMENT_RATE_SH_FIELD_NUMBER: _ClassVar[int]
    BID_SETTLEMENT_RATE_SZ_FIELD_NUMBER: _ClassVar[int]
    ASK_SETTLEMENT_RATE_SZ_FIELD_NUMBER: _ClassVar[int]
    trade_date: _timestamp_pb2.Timestamp
    currency_pair: str
    bid_referrence_rate: float
    ask_referrence_rate: float
    middle_referrence_rate: float
    bid_settlement_rate_sh: float
    ask_settlement_rate_sh: float
    bid_settlement_rate_sz: float
    ask_settlement_rate_sz: float
    def __init__(self, trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., currency_pair: _Optional[str] = ..., bid_referrence_rate: _Optional[float] = ..., ask_referrence_rate: _Optional[float] = ..., middle_referrence_rate: _Optional[float] = ..., bid_settlement_rate_sh: _Optional[float] = ..., ask_settlement_rate_sh: _Optional[float] = ..., bid_settlement_rate_sz: _Optional[float] = ..., ask_settlement_rate_sz: _Optional[float] = ...) -> None: ...

class RespGetExchangeRate(_message.Message):
    __slots__ = ["exchange_rate"]
    EXCHANGE_RATE_FIELD_NUMBER: _ClassVar[int]
    exchange_rate: _containers.RepeatedCompositeFieldContainer[ExchangeRate]
    def __init__(self, exchange_rate: _Optional[_Iterable[_Union[ExchangeRate, _Mapping]]] = ...) -> None: ...

class ReqGetTickSizeParam(_message.Message):
    __slots__ = ["unified_code"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    def __init__(self, unified_code: _Optional[str] = ...) -> None: ...

class TickSizeData(_message.Message):
    __slots__ = ["unified_code", "tick_size"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TICK_SIZE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    tick_size: float
    def __init__(self, unified_code: _Optional[str] = ..., tick_size: _Optional[float] = ...) -> None: ...

class RespGetTickSize(_message.Message):
    __slots__ = ["tick_size_list"]
    TICK_SIZE_LIST_FIELD_NUMBER: _ClassVar[int]
    tick_size_list: _containers.RepeatedCompositeFieldContainer[TickSizeData]
    def __init__(self, tick_size_list: _Optional[_Iterable[_Union[TickSizeData, _Mapping]]] = ...) -> None: ...

class ReqGetStDaysParam(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class StDaysData(_message.Message):
    __slots__ = ["unified_code", "date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    date: str
    def __init__(self, unified_code: _Optional[str] = ..., date: _Optional[str] = ...) -> None: ...

class RespGetStDays(_message.Message):
    __slots__ = ["st_days"]
    ST_DAYS_FIELD_NUMBER: _ClassVar[int]
    st_days: _containers.RepeatedCompositeFieldContainer[StDaysData]
    def __init__(self, st_days: _Optional[_Iterable[_Union[StDaysData, _Mapping]]] = ...) -> None: ...

class ReqGetSuspensionParam(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class SuspensionData(_message.Message):
    __slots__ = ["unified_code", "date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    date: str
    def __init__(self, unified_code: _Optional[str] = ..., date: _Optional[str] = ...) -> None: ...

class RespGetSuspension(_message.Message):
    __slots__ = ["suspension_days"]
    SUSPENSION_DAYS_FIELD_NUMBER: _ClassVar[int]
    suspension_days: _containers.RepeatedCompositeFieldContainer[SuspensionData]
    def __init__(self, suspension_days: _Optional[_Iterable[_Union[SuspensionData, _Mapping]]] = ...) -> None: ...
