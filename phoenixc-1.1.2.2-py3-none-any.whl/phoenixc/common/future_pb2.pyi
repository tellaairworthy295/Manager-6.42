from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetDominant(_message.Message):
    __slots__ = ["underlying_symbol", "start_date", "end_date"]
    UNDERLYING_SYMBOL_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    underlying_symbol: str
    start_date: str
    end_date: str
    def __init__(self, underlying_symbol: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class DominantContract(_message.Message):
    __slots__ = ["unified_code", "trade_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    trade_date: _timestamp_pb2.Timestamp
    def __init__(self, unified_code: _Optional[str] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class RespGetDominant(_message.Message):
    __slots__ = ["dominant_list"]
    DOMINANT_LIST_FIELD_NUMBER: _ClassVar[int]
    dominant_list: _containers.RepeatedCompositeFieldContainer[DominantContract]
    def __init__(self, dominant_list: _Optional[_Iterable[_Union[DominantContract, _Mapping]]] = ...) -> None: ...

class ReqGetContracts(_message.Message):
    __slots__ = ["underlying_symbol", "date"]
    UNDERLYING_SYMBOL_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    underlying_symbol: str
    date: str
    def __init__(self, underlying_symbol: _Optional[str] = ..., date: _Optional[str] = ...) -> None: ...

class RespGetContracts(_message.Message):
    __slots__ = ["contract_list"]
    CONTRACT_LIST_FIELD_NUMBER: _ClassVar[int]
    contract_list: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, contract_list: _Optional[_Iterable[str]] = ...) -> None: ...

class ReqGetBasis(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class BasisData(_message.Message):
    __slots__ = ["unified_code", "trade_date", "open", "close", "high", "low", "index", "close_index", "basis", "basis_rate", "basis_annual_rate", "settlement", "settle_basis", "settle_basis_rate", "settle_basis_annual_rate"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    OPEN_FIELD_NUMBER: _ClassVar[int]
    CLOSE_FIELD_NUMBER: _ClassVar[int]
    HIGH_FIELD_NUMBER: _ClassVar[int]
    LOW_FIELD_NUMBER: _ClassVar[int]
    INDEX_FIELD_NUMBER: _ClassVar[int]
    CLOSE_INDEX_FIELD_NUMBER: _ClassVar[int]
    BASIS_FIELD_NUMBER: _ClassVar[int]
    BASIS_RATE_FIELD_NUMBER: _ClassVar[int]
    BASIS_ANNUAL_RATE_FIELD_NUMBER: _ClassVar[int]
    SETTLEMENT_FIELD_NUMBER: _ClassVar[int]
    SETTLE_BASIS_FIELD_NUMBER: _ClassVar[int]
    SETTLE_BASIS_RATE_FIELD_NUMBER: _ClassVar[int]
    SETTLE_BASIS_ANNUAL_RATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    trade_date: _timestamp_pb2.Timestamp
    open: float
    close: float
    high: float
    low: float
    index: str
    close_index: float
    basis: float
    basis_rate: float
    basis_annual_rate: float
    settlement: float
    settle_basis: float
    settle_basis_rate: float
    settle_basis_annual_rate: float
    def __init__(self, unified_code: _Optional[str] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., open: _Optional[float] = ..., close: _Optional[float] = ..., high: _Optional[float] = ..., low: _Optional[float] = ..., index: _Optional[str] = ..., close_index: _Optional[float] = ..., basis: _Optional[float] = ..., basis_rate: _Optional[float] = ..., basis_annual_rate: _Optional[float] = ..., settlement: _Optional[float] = ..., settle_basis: _Optional[float] = ..., settle_basis_rate: _Optional[float] = ..., settle_basis_annual_rate: _Optional[float] = ...) -> None: ...

class RespGetBasis(_message.Message):
    __slots__ = ["basis_list"]
    BASIS_LIST_FIELD_NUMBER: _ClassVar[int]
    basis_list: _containers.RepeatedCompositeFieldContainer[BasisData]
    def __init__(self, basis_list: _Optional[_Iterable[_Union[BasisData, _Mapping]]] = ...) -> None: ...
