from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetIndicators(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class Indicator(_message.Message):
    __slots__ = ["unified_code", "trade_date", "conversion_coefficient", "conversion_value", "conversion_premium", "remaining_size", "pure_bond_value_1", "pure_bond_value_premium_1", "iv"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_COEFFICIENT_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_VALUE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_PREMIUM_FIELD_NUMBER: _ClassVar[int]
    REMAINING_SIZE_FIELD_NUMBER: _ClassVar[int]
    PURE_BOND_VALUE_1_FIELD_NUMBER: _ClassVar[int]
    PURE_BOND_VALUE_PREMIUM_1_FIELD_NUMBER: _ClassVar[int]
    IV_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    trade_date: _timestamp_pb2.Timestamp
    conversion_coefficient: float
    conversion_value: float
    conversion_premium: float
    remaining_size: float
    pure_bond_value_1: float
    pure_bond_value_premium_1: float
    iv: float
    def __init__(self, unified_code: _Optional[str] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., conversion_coefficient: _Optional[float] = ..., conversion_value: _Optional[float] = ..., conversion_premium: _Optional[float] = ..., remaining_size: _Optional[float] = ..., pure_bond_value_1: _Optional[float] = ..., pure_bond_value_premium_1: _Optional[float] = ..., iv: _Optional[float] = ...) -> None: ...

class RespGetIndicators(_message.Message):
    __slots__ = ["indicator"]
    INDICATOR_FIELD_NUMBER: _ClassVar[int]
    indicator: _containers.RepeatedCompositeFieldContainer[Indicator]
    def __init__(self, indicator: _Optional[_Iterable[_Union[Indicator, _Mapping]]] = ...) -> None: ...

class ReqGetCashFlow(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class CashFlow(_message.Message):
    __slots__ = ["unified_code", "payment_date", "record_date", "cash_flow_pretax"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    PAYMENT_DATE_FIELD_NUMBER: _ClassVar[int]
    RECORD_DATE_FIELD_NUMBER: _ClassVar[int]
    CASH_FLOW_PRETAX_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    payment_date: _timestamp_pb2.Timestamp
    record_date: _timestamp_pb2.Timestamp
    cash_flow_pretax: float
    def __init__(self, unified_code: _Optional[str] = ..., payment_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., record_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., cash_flow_pretax: _Optional[float] = ...) -> None: ...

class RespGetCashFlow(_message.Message):
    __slots__ = ["cash_flow"]
    CASH_FLOW_FIELD_NUMBER: _ClassVar[int]
    cash_flow: _containers.RepeatedCompositeFieldContainer[CashFlow]
    def __init__(self, cash_flow: _Optional[_Iterable[_Union[CashFlow, _Mapping]]] = ...) -> None: ...
