from google.protobuf import timestamp_pb2 as _timestamp_pb2
from . import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetEntrustParams(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date", "time_slice", "market", "data_type"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    TIME_SLICE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    time_slice: str
    market: str
    data_type: _common_pb2.DataType
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., time_slice: _Optional[str] = ..., market: _Optional[str] = ..., data_type: _Optional[_Union[_common_pb2.DataType, str]] = ...) -> None: ...

class ReqGetTradeParams(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date", "time_slice", "market", "data_type"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    TIME_SLICE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    time_slice: str
    market: str
    data_type: _common_pb2.DataType
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., time_slice: _Optional[str] = ..., market: _Optional[str] = ..., data_type: _Optional[_Union[_common_pb2.DataType, str]] = ...) -> None: ...

class EntrustEntity(_message.Message):
    __slots__ = ["trade_code", "unified_code", "exchange_id", "channel_no", "entrust_seq", "order_type", "order_no", "trade_date", "data_time", "price", "volume", "side"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_ID_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_NO_FIELD_NUMBER: _ClassVar[int]
    ENTRUST_SEQ_FIELD_NUMBER: _ClassVar[int]
    ORDER_TYPE_FIELD_NUMBER: _ClassVar[int]
    ORDER_NO_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    exchange_id: str
    channel_no: int
    entrust_seq: int
    order_type: str
    order_no: int
    trade_date: _timestamp_pb2.Timestamp
    data_time: _timestamp_pb2.Timestamp
    price: float
    volume: int
    side: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., exchange_id: _Optional[str] = ..., channel_no: _Optional[int] = ..., entrust_seq: _Optional[int] = ..., order_type: _Optional[str] = ..., order_no: _Optional[int] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., price: _Optional[float] = ..., volume: _Optional[int] = ..., side: _Optional[str] = ...) -> None: ...

class TradeEntity(_message.Message):
    __slots__ = ["trade_code", "unified_code", "exchange_id", "channel_no", "trade_seq", "trade_date", "data_time", "price", "volume", "turnover", "buy_no", "sell_no", "trade_flag"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_ID_FIELD_NUMBER: _ClassVar[int]
    CHANNEL_NO_FIELD_NUMBER: _ClassVar[int]
    TRADE_SEQ_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    DATA_TIME_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    TURNOVER_FIELD_NUMBER: _ClassVar[int]
    BUY_NO_FIELD_NUMBER: _ClassVar[int]
    SELL_NO_FIELD_NUMBER: _ClassVar[int]
    TRADE_FLAG_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    exchange_id: str
    channel_no: int
    trade_seq: int
    trade_date: _timestamp_pb2.Timestamp
    data_time: _timestamp_pb2.Timestamp
    price: float
    volume: int
    turnover: float
    buy_no: int
    sell_no: int
    trade_flag: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., exchange_id: _Optional[str] = ..., channel_no: _Optional[int] = ..., trade_seq: _Optional[int] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., data_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., price: _Optional[float] = ..., volume: _Optional[int] = ..., turnover: _Optional[float] = ..., buy_no: _Optional[int] = ..., sell_no: _Optional[int] = ..., trade_flag: _Optional[str] = ...) -> None: ...

class RespEntrust(_message.Message):
    __slots__ = ["entrust_dataframe", "entrust_message"]
    ENTRUST_DATAFRAME_FIELD_NUMBER: _ClassVar[int]
    ENTRUST_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    entrust_dataframe: bytes
    entrust_message: _containers.RepeatedCompositeFieldContainer[EntrustEntity]
    def __init__(self, entrust_dataframe: _Optional[bytes] = ..., entrust_message: _Optional[_Iterable[_Union[EntrustEntity, _Mapping]]] = ...) -> None: ...

class RespTrade(_message.Message):
    __slots__ = ["trade_dataframe", "trade_message"]
    TRADE_DATAFRAME_FIELD_NUMBER: _ClassVar[int]
    TRADE_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    trade_dataframe: bytes
    trade_message: _containers.RepeatedCompositeFieldContainer[TradeEntity]
    def __init__(self, trade_dataframe: _Optional[bytes] = ..., trade_message: _Optional[_Iterable[_Union[TradeEntity, _Mapping]]] = ...) -> None: ...
