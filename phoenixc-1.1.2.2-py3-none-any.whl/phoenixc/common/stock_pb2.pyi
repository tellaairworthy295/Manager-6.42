from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetSharesParams(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date", "market"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    market: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., market: _Optional[str] = ...) -> None: ...

class SharesEntity(_message.Message):
    __slots__ = ["unified_code", "trade_date", "total", "circulation_a", "free_circulation"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    CIRCULATION_A_FIELD_NUMBER: _ClassVar[int]
    FREE_CIRCULATION_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    trade_date: _timestamp_pb2.Timestamp
    total: float
    circulation_a: float
    free_circulation: float
    def __init__(self, unified_code: _Optional[str] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., total: _Optional[float] = ..., circulation_a: _Optional[float] = ..., free_circulation: _Optional[float] = ...) -> None: ...

class RespShares(_message.Message):
    __slots__ = ["shares_list"]
    SHARES_LIST_FIELD_NUMBER: _ClassVar[int]
    shares_list: _containers.RepeatedCompositeFieldContainer[SharesEntity]
    def __init__(self, shares_list: _Optional[_Iterable[_Union[SharesEntity, _Mapping]]] = ...) -> None: ...
