from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetYieldCurveParam(_message.Message):
    __slots__ = ["start_date", "end_date", "tenor", "market", "curve_code"]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    TENOR_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    CURVE_CODE_FIELD_NUMBER: _ClassVar[int]
    start_date: str
    end_date: str
    tenor: str
    market: str
    curve_code: str
    def __init__(self, start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., tenor: _Optional[str] = ..., market: _Optional[str] = ..., curve_code: _Optional[str] = ...) -> None: ...

class YieldCurve(_message.Message):
    __slots__ = ["trade_date", "tenor", "yield_value"]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    TENOR_FIELD_NUMBER: _ClassVar[int]
    YIELD_VALUE_FIELD_NUMBER: _ClassVar[int]
    trade_date: _timestamp_pb2.Timestamp
    tenor: str
    yield_value: float
    def __init__(self, trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., tenor: _Optional[str] = ..., yield_value: _Optional[float] = ...) -> None: ...

class RespGetYieldCurve(_message.Message):
    __slots__ = ["curve"]
    CURVE_FIELD_NUMBER: _ClassVar[int]
    curve: _containers.RepeatedCompositeFieldContainer[YieldCurve]
    def __init__(self, curve: _Optional[_Iterable[_Union[YieldCurve, _Mapping]]] = ...) -> None: ...
