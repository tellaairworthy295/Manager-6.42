from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetNavParam(_message.Message):
    __slots__ = ["unified_code", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class FundNav(_message.Message):
    __slots__ = ["unified_code", "trade_date", "unit_net_value", "acc_net_value", "adjusted_net_value", "change_rate", "daily_profit", "weekly_yield"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    TRADE_DATE_FIELD_NUMBER: _ClassVar[int]
    UNIT_NET_VALUE_FIELD_NUMBER: _ClassVar[int]
    ACC_NET_VALUE_FIELD_NUMBER: _ClassVar[int]
    ADJUSTED_NET_VALUE_FIELD_NUMBER: _ClassVar[int]
    CHANGE_RATE_FIELD_NUMBER: _ClassVar[int]
    DAILY_PROFIT_FIELD_NUMBER: _ClassVar[int]
    WEEKLY_YIELD_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    trade_date: _timestamp_pb2.Timestamp
    unit_net_value: float
    acc_net_value: float
    adjusted_net_value: float
    change_rate: float
    daily_profit: float
    weekly_yield: float
    def __init__(self, unified_code: _Optional[str] = ..., trade_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., unit_net_value: _Optional[float] = ..., acc_net_value: _Optional[float] = ..., adjusted_net_value: _Optional[float] = ..., change_rate: _Optional[float] = ..., daily_profit: _Optional[float] = ..., weekly_yield: _Optional[float] = ...) -> None: ...

class RespGetNav(_message.Message):
    __slots__ = ["fund_nav_list"]
    FUND_NAV_LIST_FIELD_NUMBER: _ClassVar[int]
    fund_nav_list: _containers.RepeatedCompositeFieldContainer[FundNav]
    def __init__(self, fund_nav_list: _Optional[_Iterable[_Union[FundNav, _Mapping]]] = ...) -> None: ...
