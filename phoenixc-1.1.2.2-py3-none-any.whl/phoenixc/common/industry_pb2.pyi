from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetIndustryParam(_message.Message):
    __slots__ = ["industry", "source", "date"]
    INDUSTRY_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    industry: str
    source: int
    date: str
    def __init__(self, industry: _Optional[str] = ..., source: _Optional[int] = ..., date: _Optional[str] = ...) -> None: ...

class RespGetIndustry(_message.Message):
    __slots__ = ["unified_code"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    unified_code: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, unified_code: _Optional[_Iterable[str]] = ...) -> None: ...

class ReqGetInstrumentIndustryParam(_message.Message):
    __slots__ = ["unified_code", "source", "date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    source: int
    date: str
    def __init__(self, unified_code: _Optional[str] = ..., source: _Optional[int] = ..., date: _Optional[str] = ...) -> None: ...

class ReqGetIndustryIndexParam(_message.Message):
    __slots__ = ["industry_code", "source", "level"]
    INDUSTRY_CODE_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    industry_code: str
    source: int
    level: int
    def __init__(self, industry_code: _Optional[str] = ..., source: _Optional[int] = ..., level: _Optional[int] = ...) -> None: ...

class InstrumentIndustry(_message.Message):
    __slots__ = ["unified_code", "first_industry_code", "first_industry_name", "second_industry_code", "second_industry_name", "third_industry_code", "third_industry_name"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    FIRST_INDUSTRY_CODE_FIELD_NUMBER: _ClassVar[int]
    FIRST_INDUSTRY_NAME_FIELD_NUMBER: _ClassVar[int]
    SECOND_INDUSTRY_CODE_FIELD_NUMBER: _ClassVar[int]
    SECOND_INDUSTRY_NAME_FIELD_NUMBER: _ClassVar[int]
    THIRD_INDUSTRY_CODE_FIELD_NUMBER: _ClassVar[int]
    THIRD_INDUSTRY_NAME_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    first_industry_code: str
    first_industry_name: str
    second_industry_code: str
    second_industry_name: str
    third_industry_code: str
    third_industry_name: str
    def __init__(self, unified_code: _Optional[str] = ..., first_industry_code: _Optional[str] = ..., first_industry_name: _Optional[str] = ..., second_industry_code: _Optional[str] = ..., second_industry_name: _Optional[str] = ..., third_industry_code: _Optional[str] = ..., third_industry_name: _Optional[str] = ...) -> None: ...

class RespInstrumentIndustry(_message.Message):
    __slots__ = ["instrument_industry"]
    INSTRUMENT_INDUSTRY_FIELD_NUMBER: _ClassVar[int]
    instrument_industry: _containers.RepeatedCompositeFieldContainer[InstrumentIndustry]
    def __init__(self, instrument_industry: _Optional[_Iterable[_Union[InstrumentIndustry, _Mapping]]] = ...) -> None: ...

class IndustryIndexEntity(_message.Message):
    __slots__ = ["industry_code", "unified_code"]
    INDUSTRY_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    industry_code: str
    unified_code: str
    def __init__(self, industry_code: _Optional[str] = ..., unified_code: _Optional[str] = ...) -> None: ...

class RespIndustryIndex(_message.Message):
    __slots__ = ["industry_code_list"]
    INDUSTRY_CODE_LIST_FIELD_NUMBER: _ClassVar[int]
    industry_code_list: _containers.RepeatedCompositeFieldContainer[IndustryIndexEntity]
    def __init__(self, industry_code_list: _Optional[_Iterable[_Union[IndustryIndexEntity, _Mapping]]] = ...) -> None: ...
