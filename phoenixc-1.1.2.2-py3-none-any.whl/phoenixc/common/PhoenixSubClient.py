from concurrent.futures import ThreadPoolExecutor
import logging
import threading
from typing import Iterator
from queue import Queue
import copy
import sys, os
from datetime import datetime

import grpc
import gzip
import inspect

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from phoenixc.common import phoenixSub_pb2, phoenixSub_pb2_grpc
from phoenixc.services.quote_sub_defs import QuoteSubscribeTopicKeyDef
# import phoenixSub_pb2 as phoenixSub_pb2
# import phoenixSub_pb2_grpc as phoenixSub_pb2_grpc
import time
import json
import pickle
import logging

class PhoenixSubClientMsgBaseObj():
    pass

class PhoenixSubClient:
    def __init__(
        self,
        executor: ThreadPoolExecutor,
        grpc_server_addr: str,
        grpc_channel: grpc.Channel,
        grpc_metadata = None,
        log_level = logging.INFO
    ) -> None:
        self._executor = executor
        self._grpc_server_addr = grpc_server_addr
        self._channel = grpc_channel
        self._stub = phoenixSub_pb2_grpc.PhoenixSubscriptionStub(self._channel)
        self._peer_responded = threading.Event()
        self._client_id = str(threading.get_ident())
        self._sub_map = {}
        self._has_been_started = False
        self._grpc_metadata = grpc_metadata
        self._msg_queue = Queue()
        self._response_iterator = None
        self._exiting = False
        self._reconnect_count = 0
        logging.basicConfig(level=log_level)

    def _get_client_id(self):
        return f"{self._client_id}_#{self._reconnect_count}"
    
    #在服务端或者连接异常停止之后的重连，并且还需要重新订阅已有的topic
    def _resub_all(self):
        ret_stream_iterator = None
        sub_map_copy = copy.deepcopy(self._sub_map)
        self._sub_map.clear()
        while(True):
            self._reconnect_count += 1
            sub_all_success = True
            logging.info(f"{datetime.now()} resub(#{self._reconnect_count}) request stream")
            try:
                channel = grpc.insecure_channel(self._grpc_server_addr)
                stub = phoenixSub_pb2_grpc.PhoenixSubscriptionStub(channel)
                
                if(len(sub_map_copy) == 0):
                    #避免无限循环，空耗cpu
                    sub_all_success = False
                    time.sleep(0.5)
                else:
                    #开始重新订阅所有的现有订阅
                    for k, v in sub_map_copy.items():
                        sub_handler = v[0]
                        sub_req = v[1]
                        topic = sub_req["table_name"]
                        tag = sub_req["action_name"]
                        sub_option = sub_req["sub_options"]
                        client_context = v[2]
                        sub_type = v[3]
                        try:
                            logging.info(f"{datetime.now()} resub {topic}:{tag}")
                            self.sub(sub_type, topic, tag, sub_handler, sub_option, client_context)
                        except Exception as e:
                            raise e
                
                request = phoenixSub_pb2.ReqStream()
                request.client_id = self._get_client_id()
                response_iterator = stub.StreamData(request, metadata=self._grpc_metadata)
                logging.info(f"{datetime.now()} resub(#{self._reconnect_count}) successfully!")
                return response_iterator
            except Exception as e:
                #重连失败，等待5s后重试
                logging.info(f"{datetime.now()} resub(#{self._reconnect_count}) failed {type(e)}:{str(e)}")
                time.sleep(5)
                continue
    
    def _bg_process_msg_handler(self):
        msg_handler_count = 0
        while(True):
            try:
                msg = self._msg_queue.get(True)
                if msg == None:
                    #线程退出
                    return
                topic = msg.topic
                tag = msg.tag
                msg_type = msg.msg_type
                temp_msg = msg.msg
                if msg_type == "zip_bytes":
                    temp_msg = gzip.decompress(msg.msg)

                data = pickle.loads(temp_msg)
                subPath = f"{topic}.{tag}"
                #print(f"recv msg:{subPath}")
                if subPath in self._sub_map.keys():
                    #print(f"dispatch msg:{subPath}")
                    try:
                        handler, msg_context, client_context, sub_type = self._sub_map[subPath]
                        if client_context.msg_adapter != None:
                            data = client_context.msg_adapter(data, msg_context, client_context)
                        #apply the column transformer
                        column_name = ""
                        if client_context.msg_column_transformer != None:
                            for column_name, transformer_lambda_or_constant in client_context.msg_column_transformer.items():
                                if callable(transformer_lambda_or_constant):
                                    data[column_name] = transformer_lambda_or_constant(data[column_name], data)
                                else:
                                    data[column_name] = transformer_lambda_or_constant
                        #clear the column that need to be remove
                        if client_context.msg_clear_columns != None:
                            for column_name_clear in client_context.msg_clear_columns:
                                del data[column_name_clear]
                        handler(topic, tag, msg_type, data, msg_context)
                        msg_handler_count += 1
                        if msg_handler_count % 1000 == 0:
                            logging.debug(f"{datetime.now()} _bg_process_msg_handler msg handler count:{msg_handler_count}")
                    except Exception as loop_ex:
                        logging.warn(f"_bg_process_msg_handler loop exception {str(loop_ex)}({topic}-{tag}-{column_name}:{str(data)})")
                        continue
            except Exception as e:
                logging.warn(f"_bg_process_msg_handler exception {type(e)}:{str(e)}")
                continue
    
    def _bg_process_stream_handler(self) -> None:
        
        def __response_receiver(
            self, response_iterator: Iterator[phoenixSub_pb2.StreamResMsg]
        ) -> None:
            recv_msg_count = 0
            recv_heart_beat_count = 0
            while(True):
                try:
                    for msg in response_iterator:
                            if msg.msg_type == "heartbeat":
                                recv_heart_beat_count += 1
                                #serverside_time = pickle.loads(msg.msg)
                                #print(f"heartbeat packet received, serverside time is {serverside_time}")
                                continue
                            if msg.msg_type == "error":
                                temp_msg = gzip.decompress(msg.msg)
                                error_msg = pickle.loads(temp_msg)
                                logging.error(f"{datetime.now()} [_bg_process_stream_handler] recv error:{error_msg}")
                                continue

                            if msg.msg_type == "info":
                                temp_msg = gzip.decompress(msg.msg)
                                info_msg = pickle.loads(temp_msg)
                                logging.info(f"{datetime.now()} [_bg_process_stream_handler] recv info:{info_msg}")
                                continue


                            self._msg_queue.put(msg)
                            recv_msg_count += 1
                            if recv_msg_count % 1000 == 0:
                                logging.debug(f"{datetime.now()} [_bg_process_stream_handler] recv msg count({recv_msg_count}, heartbeat packet({recv_heart_beat_count}))")
                except grpc._channel._InactiveRpcError as inactiveRpcError:
                    #尚未有数据传来，继续等待
                    continue
                except grpc._channel._MultiThreadedRendezvous as cancel_Ex:
                    if self._exiting:
                        #由客户端主动发起的stop
                        print(f"client is stopping, stop the response thread.")
                        return
                    #服务器挂掉，重连并且重新订阅
                    print(f"_bg_process_stream_handler exception ({type(cancel_Ex)} {str(cancel_Ex)})")
                    #避免占用太多cpu,等待5秒重连
                    time.sleep(5)
                    ret_iterator = self._resub_all()
                    response_iterator = ret_iterator
                    self._response_iterator = ret_iterator
                    continue
                except pickle.UnpicklingError as pickel_Ex:
                    #某条数据因为网络数据传输的问题（gzip压缩格式），该条数据无法正确解压，打印日志提示，并丢弃该条数据，处理下一条
                    print(f"_bg_process_stream_handler exception {type(e)}{str(e)}")
                    continue
                except Exception as e:
                    print(f"_bg_process_stream_handler exception {type(e)}{str(e)}")
                    #self._peer_responded.set()
                    raise e
                    
        channel = grpc.insecure_channel(self._grpc_server_addr)
        stub = phoenixSub_pb2_grpc.PhoenixSubscriptionStub(channel)
        request = phoenixSub_pb2.ReqStream()
        request.client_id = self._get_client_id()
        logging.info(f"{datetime.now()} client_id({request.client_id}) request stream")
        response_iterator = stub.StreamData(request, metadata=self._grpc_metadata)
        #for res in response_iterator:
        #    print(res)
        # Instead of consuming the responseresult on current thread, spawn a consumption thread.
        consumer_future = self._executor.submit(
                __response_receiver, self, response_iterator
        )
        self._response_iterator = response_iterator
        consumer_future.result()
        
    def start(self):
        if not self._has_been_started:
            future1 = self._executor.submit(
                self._bg_process_stream_handler
            )
            future2 = self._executor.submit(
                self._bg_process_msg_handler
            )
            self._has_been_started = True
            return (future1, future2)
        return None
        #self._bg_thread = threading.Thread(target=self._bg_process_stream_handler, args=Iterator((self,)), daemon=True)
        #self._bg_thread.start()
    
    def stop(self):
        self._exiting = True
        self._msg_queue.put(None)
        if(self._response_iterator):
             self._response_iterator.cancel()
        
    
    def sub(self, sub_type:str, topic:str, tag:str, msg_handler, sub_options:dict, client_context = None) -> None:
        request = phoenixSub_pb2.ReqSubscribe()
        request.client_id = self._get_client_id()
        request.topic = topic
        request.tag = tag
        request.sub_option = json.dumps(sub_options)
        logging.info(f"{datetime.now()} sub from client:{topic}.{tag}")
        topic_keys = QuoteSubscribeTopicKeyDef()
        if sub_type == topic_keys.MARKET:
            response = self._stub.SubscribeMarketData(request, metadata=self._grpc_metadata)
        elif sub_type == topic_keys.TICKBYTICK_ENTRUST:
            response = self._stub.SubscribeEntrust(request, metadata=self._grpc_metadata)
        elif sub_type == topic_keys.TICKBYTICK_TRADE:
            response = self._stub.SubscribeTrade(request, metadata=self._grpc_metadata)
        else:
            response = self._stub.Subscribe(request, metadata=self._grpc_metadata)
        if(response.error_code != 0):
            raise RuntimeError(response)
        if response.sub_context != None:
            sub_context_obj:dict = pickle.loads(response.sub_context)
        else:
            sub_context_obj = None
        #add the sub_context to support client-side knowing the msg structure(columes, req params .etc)
        for sub_item in response.subPath:
            if sub_item in self._sub_map.keys():
                self.unsub(sub_type, topic, tag)
            # calc the colnames and the relate colindexs
            # using the sub_context_obj["column_filter"] and client_context.msg_column_rename
            # the put the result to client_context.msg_column_name_and_index
            msg_all_column_name:list = sub_context_obj["column_filter"]
            calc_result = {}
            renamed = False
            for i, colname_item in enumerate(msg_all_column_name):
                renamed = False
                for (colname_old, colname_new) in client_context.msg_column_rename:
                    if colname_old == "" and colname_new not in calc_result.keys():
                        # generate a new colname on the fly
                        calc_result[colname_new] = None
                        continue
                    if colname_old == colname_item:
                        if colname_new != "":
                            calc_result[colname_new] = i
                        renamed = True
                if not renamed:
                    calc_result[colname_item] = i
            client_context.msg_column_name_and_index = calc_result

            self._sub_map[sub_item] = (msg_handler, sub_context_obj, client_context, sub_type)

    def unsub(self, unsub_type:str, topic:str, tag:str) -> None:
        print(f"{datetime.now()} client unsub ({topic}-{tag}) begin")
        request = phoenixSub_pb2.ReqUnsubscribe()
        request.client_id = self._get_client_id()
        request.topic = topic
        request.tag = tag
        topic_keys = QuoteSubscribeTopicKeyDef()
        if unsub_type == topic_keys.MARKET:
            response = self._stub.UnsubscribeMarketData(request, metadata=self._grpc_metadata)
        elif unsub_type == topic_keys.TICKBYTICK_ENTRUST:
            response = self._stub.UnsubscribeEntrust(request, metadata=self._grpc_metadata)
        elif unsub_type == topic_keys.TICKBYTICK_TRADE:
            response = self._stub.UnsubscribeTrade(request, metadata=self._grpc_metadata)
        else:
            response = self._stub.Unsubscribe(request, metadata=self._grpc_metadata)
        for sub_item in response.subPath:
            del self._sub_map[sub_item]
        print(f"{datetime.now()} client unsub ({topic}-{tag}) end")


if __name__ == "__main__":
    event = threading.Event()
    logging.basicConfig(level=logging.INFO)
    executor = ThreadPoolExecutor()
    #executor.submit(single_thread)

    loop_step = 0
    def sub_handler(topic, tag, mag_type, msg):
        global loop_step
        print( str(loop_step) + ": " + msg )
        loop_step += 1

    import argparse

    # 创建参数解析器
    parser = argparse.ArgumentParser()
    
    # 添加参数
    parser.add_argument("--addr", help="ddb addr use the format ip:port")
    parser.add_argument("--topic", help="ddb stream name", default=50051)
    parser.add_argument("--tag", help="action name")
    parser.add_argument("--option", help="extra options, a json string", default="")
    
    # 解析命令行参数
    args = parser.parse_args()
    
    # 获取命令行参数
    ddb_addr:str = args.addr
    topic = args.topic
    tag = args.tag
    extra_option = args.option

    ip = ddb_addr
    port = 50051
    
    if( ":" in ddb_addr):
        addr_array = ddb_addr.split(":")
        ip = addr_array[0]
        port = int(port)

    if(extra_option != "" or extra_option is not None):
        print(f'subcribe {ip}:{port} path:{topic}/{tag}')
    else:
        print(f'subcribe {ip}:{port} path:{topic}/{tag} with extra option:{extra_option}')
    
    client = PhoenixSubClient(executor, ip + ":" + str(port), grpc.insecure_channel(ip + ":" + str(port)))
    client.sub(topic, tag, sub_handler)
    #client.sub("test", "tag2", sub_handler)
    client.start()
    #time.sleep(30)
    #print("sub after start")
    #client.sub("test", "tag3", sub_handler)
    #client.sub("topic", "tag", sub_handler)

    event.wait()
