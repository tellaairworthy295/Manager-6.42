from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqIndexComponentsParam(_message.Message):
    __slots__ = ["unified_code", "date", "start_date", "end_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    date: str
    start_date: str
    end_date: str
    def __init__(self, unified_code: _Optional[str] = ..., date: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ...) -> None: ...

class IndexComponent(_message.Message):
    __slots__ = ["unified_code", "stock_unified_code", "in_date", "data_date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    STOCK_UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    IN_DATE_FIELD_NUMBER: _ClassVar[int]
    DATA_DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    stock_unified_code: str
    in_date: _timestamp_pb2.Timestamp
    data_date: _timestamp_pb2.Timestamp
    def __init__(self, unified_code: _Optional[str] = ..., stock_unified_code: _Optional[str] = ..., in_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., data_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class RespIndexComponents(_message.Message):
    __slots__ = ["index_component_list"]
    INDEX_COMPONENT_LIST_FIELD_NUMBER: _ClassVar[int]
    index_component_list: _containers.RepeatedCompositeFieldContainer[IndexComponent]
    def __init__(self, index_component_list: _Optional[_Iterable[_Union[IndexComponent, _Mapping]]] = ...) -> None: ...

class ReqIndexWeightsParam(_message.Message):
    __slots__ = ["unified_code", "date"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    date: str
    def __init__(self, unified_code: _Optional[str] = ..., date: _Optional[str] = ...) -> None: ...

class IndexWeight(_message.Message):
    __slots__ = ["unified_code", "weight"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    weight: float
    def __init__(self, unified_code: _Optional[str] = ..., weight: _Optional[float] = ...) -> None: ...

class RespIndexWeights(_message.Message):
    __slots__ = ["index_weight_list"]
    INDEX_WEIGHT_LIST_FIELD_NUMBER: _ClassVar[int]
    index_weight_list: _containers.RepeatedCompositeFieldContainer[IndexWeight]
    def __init__(self, index_weight_list: _Optional[_Iterable[_Union[IndexWeight, _Mapping]]] = ...) -> None: ...
