from google.protobuf import timestamp_pb2 as _timestamp_pb2
from . import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetFactorParams(_message.Message):
    __slots__ = ["unified_code", "factor", "frequency", "start_date", "end_date", "universe", "adjust_type", "data_type"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    FACTOR_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    UNIVERSE_FIELD_NUMBER: _ClassVar[int]
    ADJUST_TYPE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    factor: str
    frequency: str
    start_date: str
    end_date: str
    universe: str
    adjust_type: str
    data_type: _common_pb2.DataType
    def __init__(self, unified_code: _Optional[str] = ..., factor: _Optional[str] = ..., frequency: _Optional[str] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., universe: _Optional[str] = ..., adjust_type: _Optional[str] = ..., data_type: _Optional[_Union[_common_pb2.DataType, str]] = ...) -> None: ...

class FactorEntity(_message.Message):
    __slots__ = ["unified_code", "date", "factor_name", "factor_value", "frequency"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    FACTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    FACTOR_VALUE_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    date: _timestamp_pb2.Timestamp
    factor_name: str
    factor_value: float
    frequency: str
    def __init__(self, unified_code: _Optional[str] = ..., date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., factor_name: _Optional[str] = ..., factor_value: _Optional[float] = ..., frequency: _Optional[str] = ...) -> None: ...

class RespFactor(_message.Message):
    __slots__ = ["factor_list", "factor_dataframe"]
    FACTOR_LIST_FIELD_NUMBER: _ClassVar[int]
    FACTOR_DATAFRAME_FIELD_NUMBER: _ClassVar[int]
    factor_list: _containers.RepeatedCompositeFieldContainer[FactorEntity]
    factor_dataframe: bytes
    def __init__(self, factor_list: _Optional[_Iterable[_Union[FactorEntity, _Mapping]]] = ..., factor_dataframe: _Optional[bytes] = ...) -> None: ...
