from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqGetTradingDatesParams(_message.Message):
    __slots__ = ["start_date", "end_date", "exchange"]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    start_date: str
    end_date: str
    exchange: str
    def __init__(self, start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., exchange: _Optional[str] = ...) -> None: ...

class TradingDatesData(_message.Message):
    __slots__ = ["trading_date"]
    TRADING_DATE_FIELD_NUMBER: _ClassVar[int]
    trading_date: str
    def __init__(self, trading_date: _Optional[str] = ...) -> None: ...

class RespGetTradingDatesData(_message.Message):
    __slots__ = ["data"]
    DATA_FIELD_NUMBER: _ClassVar[int]
    data: _containers.RepeatedCompositeFieldContainer[TradingDatesData]
    def __init__(self, data: _Optional[_Iterable[_Union[TradingDatesData, _Mapping]]] = ...) -> None: ...

class ReqGetPreviousTradingDateParams(_message.Message):
    __slots__ = ["date", "n", "exchange"]
    DATE_FIELD_NUMBER: _ClassVar[int]
    N_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    date: str
    n: int
    exchange: str
    def __init__(self, date: _Optional[str] = ..., n: _Optional[int] = ..., exchange: _Optional[str] = ...) -> None: ...

class ReqGetNextTradingDateParams(_message.Message):
    __slots__ = ["date", "n", "exchange"]
    DATE_FIELD_NUMBER: _ClassVar[int]
    N_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    date: str
    n: int
    exchange: str
    def __init__(self, date: _Optional[str] = ..., n: _Optional[int] = ..., exchange: _Optional[str] = ...) -> None: ...

class ReqGetTradeTimeParams(_message.Message):
    __slots__ = ["exchange", "major_type", "minor_type"]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    MAJOR_TYPE_FIELD_NUMBER: _ClassVar[int]
    MINOR_TYPE_FIELD_NUMBER: _ClassVar[int]
    exchange: str
    major_type: str
    minor_type: str
    def __init__(self, exchange: _Optional[str] = ..., major_type: _Optional[str] = ..., minor_type: _Optional[str] = ...) -> None: ...

class RespGetTradeTimeData(_message.Message):
    __slots__ = ["trade_time"]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_time: str
    def __init__(self, trade_time: _Optional[str] = ...) -> None: ...
