from google.protobuf import timestamp_pb2 as _timestamp_pb2
from . import common_pb2 as _common_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ReqAllInstrumentsParams(_message.Message):
    __slots__ = ["type", "market", "date", "exchange", "data_type"]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    type: str
    market: str
    date: str
    exchange: _containers.RepeatedScalarFieldContainer[str]
    data_type: _common_pb2.DataType
    def __init__(self, type: _Optional[str] = ..., market: _Optional[str] = ..., date: _Optional[str] = ..., exchange: _Optional[_Iterable[str]] = ..., data_type: _Optional[_Union[_common_pb2.DataType, str]] = ...) -> None: ...

class ReqInstrumentsParams(_message.Message):
    __slots__ = ["unified_code", "market"]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    unified_code: str
    market: str
    def __init__(self, unified_code: _Optional[str] = ..., market: _Optional[str] = ...) -> None: ...

class ReqPriceParams(_message.Message):
    __slots__ = ["order_book_ids", "start_date", "end_date", "frequency", "fields", "market", "time_slice"]
    ORDER_BOOK_IDS_FIELD_NUMBER: _ClassVar[int]
    START_DATE_FIELD_NUMBER: _ClassVar[int]
    END_DATE_FIELD_NUMBER: _ClassVar[int]
    FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    FIELDS_FIELD_NUMBER: _ClassVar[int]
    MARKET_FIELD_NUMBER: _ClassVar[int]
    TIME_SLICE_FIELD_NUMBER: _ClassVar[int]
    order_book_ids: _containers.RepeatedScalarFieldContainer[str]
    start_date: str
    end_date: str
    frequency: str
    fields: _containers.RepeatedScalarFieldContainer[str]
    market: str
    time_slice: str
    def __init__(self, order_book_ids: _Optional[_Iterable[str]] = ..., start_date: _Optional[str] = ..., end_date: _Optional[str] = ..., frequency: _Optional[str] = ..., fields: _Optional[_Iterable[str]] = ..., market: _Optional[str] = ..., time_slice: _Optional[str] = ...) -> None: ...

class StockBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "round_lot", "listed_date", "de_listed_date", "exchange", "issue_price", "board_type", "special_type", "cross_market", "status", "security_layer_type"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    BOARD_TYPE_FIELD_NUMBER: _ClassVar[int]
    SPECIAL_TYPE_FIELD_NUMBER: _ClassVar[int]
    CROSS_MARKET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SECURITY_LAYER_TYPE_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    round_lot: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    issue_price: float
    board_type: str
    special_type: str
    cross_market: int
    status: str
    security_layer_type: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., round_lot: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., issue_price: _Optional[float] = ..., board_type: _Optional[str] = ..., special_type: _Optional[str] = ..., cross_market: _Optional[int] = ..., status: _Optional[str] = ..., security_layer_type: _Optional[str] = ...) -> None: ...

class StockHKBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "round_lot", "listed_date", "de_listed_date", "exchange", "issue_price", "board_name", "is_hksc", "status"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    BOARD_NAME_FIELD_NUMBER: _ClassVar[int]
    IS_HKSC_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    round_lot: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    issue_price: float
    board_name: str
    is_hksc: int
    status: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., round_lot: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., issue_price: _Optional[float] = ..., board_name: _Optional[str] = ..., is_hksc: _Optional[int] = ..., status: _Optional[str] = ...) -> None: ...

class SpotBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., round_lot: _Optional[float] = ...) -> None: ...

class OptionBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "listed_date", "de_listed_date", "contract_multiplier", "underlying_order_book_id", "stand_contract_code", "exchange", "strike_price", "option_type", "exercise_type", "end_delivery_date", "exercise_end", "ex_code", "adjust_sign", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    UNDERLYING_ORDER_BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    STAND_CONTRACT_CODE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    STRIKE_PRICE_FIELD_NUMBER: _ClassVar[int]
    OPTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXERCISE_TYPE_FIELD_NUMBER: _ClassVar[int]
    END_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    EXERCISE_END_FIELD_NUMBER: _ClassVar[int]
    EX_CODE_FIELD_NUMBER: _ClassVar[int]
    ADJUST_SIGN_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    contract_multiplier: float
    underlying_order_book_id: str
    stand_contract_code: str
    exchange: str
    strike_price: float
    option_type: str
    exercise_type: str
    end_delivery_date: _timestamp_pb2.Timestamp
    exercise_end: _timestamp_pb2.Timestamp
    ex_code: str
    adjust_sign: str
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., contract_multiplier: _Optional[float] = ..., underlying_order_book_id: _Optional[str] = ..., stand_contract_code: _Optional[str] = ..., exchange: _Optional[str] = ..., strike_price: _Optional[float] = ..., option_type: _Optional[str] = ..., exercise_type: _Optional[str] = ..., end_delivery_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exercise_end: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., ex_code: _Optional[str] = ..., adjust_sign: _Optional[str] = ..., round_lot: _Optional[float] = ...) -> None: ...

class FutureBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "underlying_order_book_id", "stand_contract_code", "margin_rate_long", "margin_rate_short", "listed_date", "de_listed_date", "contract_multiplier", "end_delivery_date", "contract_type", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    UNDERLYING_ORDER_BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    STAND_CONTRACT_CODE_FIELD_NUMBER: _ClassVar[int]
    MARGIN_RATE_LONG_FIELD_NUMBER: _ClassVar[int]
    MARGIN_RATE_SHORT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    END_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    underlying_order_book_id: str
    stand_contract_code: str
    margin_rate_long: float
    margin_rate_short: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    contract_multiplier: float
    end_delivery_date: _timestamp_pb2.Timestamp
    contract_type: str
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., underlying_order_book_id: _Optional[str] = ..., stand_contract_code: _Optional[str] = ..., margin_rate_long: _Optional[float] = ..., margin_rate_short: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., contract_multiplier: _Optional[float] = ..., end_delivery_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., contract_type: _Optional[str] = ..., round_lot: _Optional[float] = ...) -> None: ...

class IndexBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "status", "listed_date", "de_listed_date", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    status: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., status: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., round_lot: _Optional[float] = ...) -> None: ...

class BondRepoBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "exchange", "symbol", "listed_date", "round_lot", "status"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    exchange: str
    symbol: str
    listed_date: str
    round_lot: float
    status: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., exchange: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[str] = ..., round_lot: _Optional[float] = ..., status: _Optional[str] = ...) -> None: ...

class FundBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "company_name", "establishment_date", "listed_date", "de_listed_date", "stop_date", "benchmark", "latest_size", "min_subscribe_amount", "company_id", "trustee_id", "status", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    COMPANY_NAME_FIELD_NUMBER: _ClassVar[int]
    ESTABLISHMENT_DATE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    STOP_DATE_FIELD_NUMBER: _ClassVar[int]
    BENCHMARK_FIELD_NUMBER: _ClassVar[int]
    LATEST_SIZE_FIELD_NUMBER: _ClassVar[int]
    MIN_SUBSCRIBE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    TRUSTEE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    company_name: str
    establishment_date: _timestamp_pb2.Timestamp
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    stop_date: _timestamp_pb2.Timestamp
    benchmark: str
    latest_size: float
    min_subscribe_amount: float
    company_id: str
    trustee_id: str
    status: str
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., company_name: _Optional[str] = ..., establishment_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., stop_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., benchmark: _Optional[str] = ..., latest_size: _Optional[float] = ..., min_subscribe_amount: _Optional[float] = ..., company_id: _Optional[str] = ..., trustee_id: _Optional[str] = ..., status: _Optional[str] = ..., round_lot: _Optional[float] = ...) -> None: ...

class BondBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "issue_price", "listed_date", "de_listed_date", "exchange", "status", "total_issue_size", "coupon_rate", "coupon_frequency", "special_bond_type", "value_date", "maturity_date", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ISSUE_SIZE_FIELD_NUMBER: _ClassVar[int]
    COUPON_RATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    SPECIAL_BOND_TYPE_FIELD_NUMBER: _ClassVar[int]
    VALUE_DATE_FIELD_NUMBER: _ClassVar[int]
    MATURITY_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    issue_price: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    status: str
    total_issue_size: float
    coupon_rate: float
    coupon_frequency: str
    special_bond_type: str
    value_date: _timestamp_pb2.Timestamp
    maturity_date: _timestamp_pb2.Timestamp
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., issue_price: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., status: _Optional[str] = ..., total_issue_size: _Optional[float] = ..., coupon_rate: _Optional[float] = ..., coupon_frequency: _Optional[str] = ..., special_bond_type: _Optional[str] = ..., value_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., maturity_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., round_lot: _Optional[float] = ...) -> None: ...

class ConvertibleBasicData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "listed_date", "de_listed_date", "exchange", "status", "stock_code", "issue_price", "total_issue_size", "value_date", "maturity_date", "coupon_rate", "coupon_frequency", "conversion_start_date", "conversion_end_date", "round_lot"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_CODE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ISSUE_SIZE_FIELD_NUMBER: _ClassVar[int]
    VALUE_DATE_FIELD_NUMBER: _ClassVar[int]
    MATURITY_DATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_RATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_START_DATE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_END_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    status: str
    stock_code: str
    issue_price: float
    total_issue_size: float
    value_date: _timestamp_pb2.Timestamp
    maturity_date: _timestamp_pb2.Timestamp
    coupon_rate: float
    coupon_frequency: str
    conversion_start_date: _timestamp_pb2.Timestamp
    conversion_end_date: _timestamp_pb2.Timestamp
    round_lot: float
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., status: _Optional[str] = ..., stock_code: _Optional[str] = ..., issue_price: _Optional[float] = ..., total_issue_size: _Optional[float] = ..., value_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., maturity_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., coupon_rate: _Optional[float] = ..., coupon_frequency: _Optional[str] = ..., conversion_start_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., conversion_end_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., round_lot: _Optional[float] = ...) -> None: ...

class CommonBasicData(_message.Message):
    __slots__ = ["trade_code", "wind_code", "symbol", "listed_date", "de_listed_date", "exchange", "type"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    WIND_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    wind_code: str
    symbol: str
    listed_date: str
    de_listed_date: str
    exchange: str
    type: str
    def __init__(self, trade_code: _Optional[str] = ..., wind_code: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[str] = ..., de_listed_date: _Optional[str] = ..., exchange: _Optional[str] = ..., type: _Optional[str] = ...) -> None: ...

class RespInstrumentDataList(_message.Message):
    __slots__ = ["stock_basic_list", "index_basic_list", "fund_basic_list", "spot_basic_list", "option_basic_list", "future_basic_list", "bond_basic_list", "bond_repo_basic_data", "basic_list", "convertible_basic_list", "stock_hk_basic_list", "basic_dataframe"]
    STOCK_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    INDEX_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    FUND_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    SPOT_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    OPTION_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    FUTURE_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    BOND_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    BOND_REPO_BASIC_DATA_FIELD_NUMBER: _ClassVar[int]
    BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    CONVERTIBLE_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    STOCK_HK_BASIC_LIST_FIELD_NUMBER: _ClassVar[int]
    BASIC_DATAFRAME_FIELD_NUMBER: _ClassVar[int]
    stock_basic_list: _containers.RepeatedCompositeFieldContainer[StockBasicData]
    index_basic_list: _containers.RepeatedCompositeFieldContainer[IndexBasicData]
    fund_basic_list: _containers.RepeatedCompositeFieldContainer[FundBasicData]
    spot_basic_list: _containers.RepeatedCompositeFieldContainer[SpotBasicData]
    option_basic_list: _containers.RepeatedCompositeFieldContainer[OptionBasicData]
    future_basic_list: _containers.RepeatedCompositeFieldContainer[FutureBasicData]
    bond_basic_list: _containers.RepeatedCompositeFieldContainer[BondBasicData]
    bond_repo_basic_data: _containers.RepeatedCompositeFieldContainer[BondRepoBasicData]
    basic_list: _containers.RepeatedCompositeFieldContainer[CommonBasicData]
    convertible_basic_list: _containers.RepeatedCompositeFieldContainer[ConvertibleBasicData]
    stock_hk_basic_list: _containers.RepeatedCompositeFieldContainer[StockHKBasicData]
    basic_dataframe: bytes
    def __init__(self, stock_basic_list: _Optional[_Iterable[_Union[StockBasicData, _Mapping]]] = ..., index_basic_list: _Optional[_Iterable[_Union[IndexBasicData, _Mapping]]] = ..., fund_basic_list: _Optional[_Iterable[_Union[FundBasicData, _Mapping]]] = ..., spot_basic_list: _Optional[_Iterable[_Union[SpotBasicData, _Mapping]]] = ..., option_basic_list: _Optional[_Iterable[_Union[OptionBasicData, _Mapping]]] = ..., future_basic_list: _Optional[_Iterable[_Union[FutureBasicData, _Mapping]]] = ..., bond_basic_list: _Optional[_Iterable[_Union[BondBasicData, _Mapping]]] = ..., bond_repo_basic_data: _Optional[_Iterable[_Union[BondRepoBasicData, _Mapping]]] = ..., basic_list: _Optional[_Iterable[_Union[CommonBasicData, _Mapping]]] = ..., convertible_basic_list: _Optional[_Iterable[_Union[ConvertibleBasicData, _Mapping]]] = ..., stock_hk_basic_list: _Optional[_Iterable[_Union[StockHKBasicData, _Mapping]]] = ..., basic_dataframe: _Optional[bytes] = ...) -> None: ...

class StockDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "round_lot", "listed_date", "de_listed_date", "exchange", "issue_price", "board_type", "special_type", "cross_market", "status", "security_layer_type", "type", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    BOARD_TYPE_FIELD_NUMBER: _ClassVar[int]
    SPECIAL_TYPE_FIELD_NUMBER: _ClassVar[int]
    CROSS_MARKET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SECURITY_LAYER_TYPE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    round_lot: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    issue_price: float
    board_type: str
    special_type: str
    cross_market: int
    status: str
    security_layer_type: str
    type: str
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., round_lot: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., issue_price: _Optional[float] = ..., board_type: _Optional[str] = ..., special_type: _Optional[str] = ..., cross_market: _Optional[int] = ..., status: _Optional[str] = ..., security_layer_type: _Optional[str] = ..., type: _Optional[str] = ..., trade_time: _Optional[str] = ...) -> None: ...

class IndexDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "round_lot", "exchange", "type", "listed_date", "de_listed_date", "status", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    round_lot: float
    exchange: str
    type: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    status: str
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., round_lot: _Optional[float] = ..., exchange: _Optional[str] = ..., type: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., status: _Optional[str] = ..., trade_time: _Optional[str] = ...) -> None: ...

class FundDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "type", "company_name", "establishment_date", "listed_date", "de_listed_date", "stop_date", "benchmark", "latest_size", "min_subscribe_amount", "company_id", "trustee_id", "status", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    COMPANY_NAME_FIELD_NUMBER: _ClassVar[int]
    ESTABLISHMENT_DATE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    STOP_DATE_FIELD_NUMBER: _ClassVar[int]
    BENCHMARK_FIELD_NUMBER: _ClassVar[int]
    LATEST_SIZE_FIELD_NUMBER: _ClassVar[int]
    MIN_SUBSCRIBE_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    COMPANY_ID_FIELD_NUMBER: _ClassVar[int]
    TRUSTEE_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    type: str
    company_name: str
    establishment_date: _timestamp_pb2.Timestamp
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    stop_date: _timestamp_pb2.Timestamp
    benchmark: str
    latest_size: float
    min_subscribe_amount: float
    company_id: str
    trustee_id: str
    status: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., type: _Optional[str] = ..., company_name: _Optional[str] = ..., establishment_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., stop_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., benchmark: _Optional[str] = ..., latest_size: _Optional[float] = ..., min_subscribe_amount: _Optional[float] = ..., company_id: _Optional[str] = ..., trustee_id: _Optional[str] = ..., status: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class FutureDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "underlying_order_book_id", "stand_contract_code", "margin_rate_long", "margin_rate_short", "listed_date", "de_listed_date", "contract_multiplier", "end_delivery_date", "contract_type", "type", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    UNDERLYING_ORDER_BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    STAND_CONTRACT_CODE_FIELD_NUMBER: _ClassVar[int]
    MARGIN_RATE_LONG_FIELD_NUMBER: _ClassVar[int]
    MARGIN_RATE_SHORT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    END_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_TYPE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    underlying_order_book_id: str
    stand_contract_code: str
    margin_rate_long: float
    margin_rate_short: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    contract_multiplier: float
    end_delivery_date: _timestamp_pb2.Timestamp
    contract_type: str
    type: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., underlying_order_book_id: _Optional[str] = ..., stand_contract_code: _Optional[str] = ..., margin_rate_long: _Optional[float] = ..., margin_rate_short: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., contract_multiplier: _Optional[float] = ..., end_delivery_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., contract_type: _Optional[str] = ..., type: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class OptionDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "listed_date", "de_listed_date", "type", "contract_multiplier", "underlying_order_book_id", "stand_contract_code", "exchange", "strike_price", "option_type", "exercise_type", "end_delivery_date", "exercise_end", "ex_code", "adjust_sign", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_MULTIPLIER_FIELD_NUMBER: _ClassVar[int]
    UNDERLYING_ORDER_BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    STAND_CONTRACT_CODE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    STRIKE_PRICE_FIELD_NUMBER: _ClassVar[int]
    OPTION_TYPE_FIELD_NUMBER: _ClassVar[int]
    EXERCISE_TYPE_FIELD_NUMBER: _ClassVar[int]
    END_DELIVERY_DATE_FIELD_NUMBER: _ClassVar[int]
    EXERCISE_END_FIELD_NUMBER: _ClassVar[int]
    EX_CODE_FIELD_NUMBER: _ClassVar[int]
    ADJUST_SIGN_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    type: str
    contract_multiplier: float
    underlying_order_book_id: str
    stand_contract_code: str
    exchange: str
    strike_price: float
    option_type: str
    exercise_type: str
    end_delivery_date: _timestamp_pb2.Timestamp
    exercise_end: _timestamp_pb2.Timestamp
    ex_code: str
    adjust_sign: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., type: _Optional[str] = ..., contract_multiplier: _Optional[float] = ..., underlying_order_book_id: _Optional[str] = ..., stand_contract_code: _Optional[str] = ..., exchange: _Optional[str] = ..., strike_price: _Optional[float] = ..., option_type: _Optional[str] = ..., exercise_type: _Optional[str] = ..., end_delivery_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exercise_end: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., ex_code: _Optional[str] = ..., adjust_sign: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class BondDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "listed_date", "de_listed_date", "type", "status", "issue_price", "total_issue_size", "coupon_rate", "coupon_frequency", "special_bond_type", "value_date", "maturity_date", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ISSUE_SIZE_FIELD_NUMBER: _ClassVar[int]
    COUPON_RATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    SPECIAL_BOND_TYPE_FIELD_NUMBER: _ClassVar[int]
    VALUE_DATE_FIELD_NUMBER: _ClassVar[int]
    MATURITY_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    type: str
    status: str
    issue_price: float
    total_issue_size: float
    coupon_rate: float
    coupon_frequency: str
    special_bond_type: str
    value_date: _timestamp_pb2.Timestamp
    maturity_date: _timestamp_pb2.Timestamp
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., type: _Optional[str] = ..., status: _Optional[str] = ..., issue_price: _Optional[float] = ..., total_issue_size: _Optional[float] = ..., coupon_rate: _Optional[float] = ..., coupon_frequency: _Optional[str] = ..., special_bond_type: _Optional[str] = ..., value_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., maturity_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class SpotDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "type", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    type: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., type: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class RepoDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "listed_date", "status", "type", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    listed_date: _timestamp_pb2.Timestamp
    status: str
    type: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., status: _Optional[str] = ..., type: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class ConvertibleDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "exchange", "listed_date", "de_listed_date", "type", "status", "stock_code", "issue_price", "total_issue_size", "value_date", "maturity_date", "coupon_rate", "coupon_frequency", "conversion_start_date", "conversion_end_date", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STOCK_CODE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ISSUE_SIZE_FIELD_NUMBER: _ClassVar[int]
    VALUE_DATE_FIELD_NUMBER: _ClassVar[int]
    MATURITY_DATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_RATE_FIELD_NUMBER: _ClassVar[int]
    COUPON_FREQUENCY_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_START_DATE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_END_DATE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    exchange: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    type: str
    status: str
    stock_code: str
    issue_price: float
    total_issue_size: float
    value_date: _timestamp_pb2.Timestamp
    maturity_date: _timestamp_pb2.Timestamp
    coupon_rate: float
    coupon_frequency: str
    conversion_start_date: _timestamp_pb2.Timestamp
    conversion_end_date: _timestamp_pb2.Timestamp
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., exchange: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., type: _Optional[str] = ..., status: _Optional[str] = ..., stock_code: _Optional[str] = ..., issue_price: _Optional[float] = ..., total_issue_size: _Optional[float] = ..., value_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., maturity_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., coupon_rate: _Optional[float] = ..., coupon_frequency: _Optional[str] = ..., conversion_start_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., conversion_end_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class DefaultSecurityDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "listed_date", "de_listed_date", "exchange", "type", "round_lot", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    type: str
    round_lot: float
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., type: _Optional[str] = ..., round_lot: _Optional[float] = ..., trade_time: _Optional[str] = ...) -> None: ...

class StockHKDetailData(_message.Message):
    __slots__ = ["trade_code", "unified_code", "symbol", "round_lot", "listed_date", "de_listed_date", "exchange", "issue_price", "board_name", "is_hksc", "status", "type", "trade_time"]
    TRADE_CODE_FIELD_NUMBER: _ClassVar[int]
    UNIFIED_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    ROUND_LOT_FIELD_NUMBER: _ClassVar[int]
    LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    DE_LISTED_DATE_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_FIELD_NUMBER: _ClassVar[int]
    ISSUE_PRICE_FIELD_NUMBER: _ClassVar[int]
    BOARD_NAME_FIELD_NUMBER: _ClassVar[int]
    IS_HKSC_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TRADE_TIME_FIELD_NUMBER: _ClassVar[int]
    trade_code: str
    unified_code: str
    symbol: str
    round_lot: float
    listed_date: _timestamp_pb2.Timestamp
    de_listed_date: _timestamp_pb2.Timestamp
    exchange: str
    issue_price: float
    board_name: str
    is_hksc: int
    status: str
    type: str
    trade_time: str
    def __init__(self, trade_code: _Optional[str] = ..., unified_code: _Optional[str] = ..., symbol: _Optional[str] = ..., round_lot: _Optional[float] = ..., listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., de_listed_date: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., exchange: _Optional[str] = ..., issue_price: _Optional[float] = ..., board_name: _Optional[str] = ..., is_hksc: _Optional[int] = ..., status: _Optional[str] = ..., type: _Optional[str] = ..., trade_time: _Optional[str] = ...) -> None: ...

class RespInstrumentDetailDataList(_message.Message):
    __slots__ = ["stock_detail_list", "index_detail_list", "fund_detail_list", "spot_detail_list", "option_detail_list", "future_detail_list", "bond_detail_list", "repo_detail_list", "convertible_detail_list", "detail_list", "stock_hk_detail_list"]
    STOCK_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    INDEX_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    FUND_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    SPOT_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    OPTION_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    FUTURE_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    BOND_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    REPO_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    CONVERTIBLE_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    STOCK_HK_DETAIL_LIST_FIELD_NUMBER: _ClassVar[int]
    stock_detail_list: _containers.RepeatedCompositeFieldContainer[StockDetailData]
    index_detail_list: _containers.RepeatedCompositeFieldContainer[IndexDetailData]
    fund_detail_list: _containers.RepeatedCompositeFieldContainer[FundDetailData]
    spot_detail_list: _containers.RepeatedCompositeFieldContainer[SpotDetailData]
    option_detail_list: _containers.RepeatedCompositeFieldContainer[OptionDetailData]
    future_detail_list: _containers.RepeatedCompositeFieldContainer[FutureDetailData]
    bond_detail_list: _containers.RepeatedCompositeFieldContainer[BondDetailData]
    repo_detail_list: _containers.RepeatedCompositeFieldContainer[RepoDetailData]
    convertible_detail_list: _containers.RepeatedCompositeFieldContainer[ConvertibleDetailData]
    detail_list: _containers.RepeatedCompositeFieldContainer[DefaultSecurityDetailData]
    stock_hk_detail_list: _containers.RepeatedCompositeFieldContainer[StockHKDetailData]
    def __init__(self, stock_detail_list: _Optional[_Iterable[_Union[StockDetailData, _Mapping]]] = ..., index_detail_list: _Optional[_Iterable[_Union[IndexDetailData, _Mapping]]] = ..., fund_detail_list: _Optional[_Iterable[_Union[FundDetailData, _Mapping]]] = ..., spot_detail_list: _Optional[_Iterable[_Union[SpotDetailData, _Mapping]]] = ..., option_detail_list: _Optional[_Iterable[_Union[OptionDetailData, _Mapping]]] = ..., future_detail_list: _Optional[_Iterable[_Union[FutureDetailData, _Mapping]]] = ..., bond_detail_list: _Optional[_Iterable[_Union[BondDetailData, _Mapping]]] = ..., repo_detail_list: _Optional[_Iterable[_Union[RepoDetailData, _Mapping]]] = ..., convertible_detail_list: _Optional[_Iterable[_Union[ConvertibleDetailData, _Mapping]]] = ..., detail_list: _Optional[_Iterable[_Union[DefaultSecurityDetailData, _Mapping]]] = ..., stock_hk_detail_list: _Optional[_Iterable[_Union[StockHKDetailData, _Mapping]]] = ...) -> None: ...
