from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class ReqSubscribe(_message.Message):
    __slots__ = ["client_id", "topic", "tag", "sub_option"]
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    SUB_OPTION_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    topic: str
    tag: str
    sub_option: str
    def __init__(self, client_id: _Optional[str] = ..., topic: _Optional[str] = ..., tag: _Optional[str] = ..., sub_option: _Optional[str] = ...) -> None: ...

class ReqUnsubscribe(_message.Message):
    __slots__ = ["client_id", "topic", "tag"]
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    topic: str
    tag: str
    def __init__(self, client_id: _Optional[str] = ..., topic: _Optional[str] = ..., tag: _Optional[str] = ...) -> None: ...

class ResSubscribe(_message.Message):
    __slots__ = ["error_code", "error_desc", "subPath", "sub_context"]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ERROR_DESC_FIELD_NUMBER: _ClassVar[int]
    SUBPATH_FIELD_NUMBER: _ClassVar[int]
    SUB_CONTEXT_FIELD_NUMBER: _ClassVar[int]
    error_code: int
    error_desc: str
    subPath: _containers.RepeatedScalarFieldContainer[str]
    sub_context: bytes
    def __init__(self, error_code: _Optional[int] = ..., error_desc: _Optional[str] = ..., subPath: _Optional[_Iterable[str]] = ..., sub_context: _Optional[bytes] = ...) -> None: ...

class ReqStream(_message.Message):
    __slots__ = ["client_id"]
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    def __init__(self, client_id: _Optional[str] = ...) -> None: ...

class StreamResMsg(_message.Message):
    __slots__ = ["topic", "tag", "msg_type", "msg"]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    MSG_TYPE_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    topic: str
    tag: str
    msg_type: str
    msg: bytes
    def __init__(self, topic: _Optional[str] = ..., tag: _Optional[str] = ..., msg_type: _Optional[str] = ..., msg: _Optional[bytes] = ...) -> None: ...
