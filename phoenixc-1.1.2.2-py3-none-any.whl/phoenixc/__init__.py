"""
-*- coding: utf-8 -*-
@Time : 2024
"""

from ._version import get_versions
__version__ = get_versions()

from phoenixc.services.init import Init
init_instance = Init()
init = init_instance.init
info = init_instance.info

from phoenixc.services.all_instruments import AllInstruments
from phoenixc.services.instruments import instruments
from phoenixc.services.get_trading_dates import get_trading_dates
from phoenixc.services.current_snapshot import current_snapshot
from phoenixc.services.get_price import GetPrice
from phoenixc.services.get_trade import Trade
from phoenixc.services.get_entrust import Entrust
from phoenixc.services.current_minute import CurrentMinute
from phoenixc.services.get_cfe_level2 import GetCfeLevel2
from phoenixc.services.stock.get_ex_factor import GetExFactor
from phoenixc.services.get_previous_trading_date import get_previous_trading_date
from phoenixc.services.get_next_trading_date import get_next_trading_date
from phoenixc.services.stock.get_st_days import get_st_days
from phoenixc.services.stock.get_suspension_days import get_suspension_days

from phoenixc.services.get_trade_time import get_trade_time

from phoenixc.services.stock.get_dividend import GetDividend
from phoenixc.services.stock.get_split import GetSplit
from phoenixc.services.get_factor import GetFactor
from phoenixc.services.fund.get_nav import GetNav
from phoenixc.services.index.index_components import IndexComponents
from phoenixc.services.index.index_weights import IndexWeights
from phoenixc.services.futures.get_dominant import GetDominant
from phoenixc.services.futures.get_contracts import GetContracts
from phoenixc.services.futures.get_basis import GetBasis
from phoenixc.services.stock.get_instrument_industry import GetInstrumentIndustry
from phoenixc.services.stock.get_industry import GetIndustry
from phoenixc.services.convertible.get_indicators import GetIndicators
from phoenixc.services.convertible.get_cash_flow import GetCashFlow
from phoenixc.services.get_exchange_rate import GetExchangeRate
from phoenixc.services.get_yield_curve import GetYieldCurve
from phoenixc.services.get_tick_size import GetTickSize
from phoenixc.services.get_shares import GetShares

all_instruments = AllInstruments().all_instruments
instruments = instruments
get_trading_dates = get_trading_dates
current_snapshot = current_snapshot
get_price = GetPrice().get_price
get_trade = Trade().get_trade
get_entrust = Entrust().get_entrust
current_minute = CurrentMinute().current_minute
get_cfe_level2 = GetCfeLevel2().get_cfe_level2
get_ex_factor = GetExFactor().get_ex_factor
get_previous_trading_date = get_previous_trading_date
get_next_trading_date = get_next_trading_date
get_st_days = get_st_days
get_suspension_days = get_suspension_days

get_trade_time = get_trade_time

get_dividend = GetDividend().get_dividend
get_split = GetSplit().get_split
get_factor = GetFactor().get_factor
get_nav = GetNav().get_nav
index_components = IndexComponents().index_components
index_weights = IndexWeights().index_weights
get_instrument_industry = GetInstrumentIndustry().get_instrument_industry
get_industry = GetIndustry().get_industry
get_industry_index = GetIndustry().get_industry_index
get_exchange_rate = GetExchangeRate().get_exchange_rate
get_yield_curve = GetYieldCurve().get_yield_curve
get_tick_size = GetTickSize().get_tick_size

get_shares=GetShares().get_shares

class futures:
    get_dominant = GetDominant().get_dominant
    get_contracts = GetContracts().get_contracts
    get_basis = GetBasis().get_basis

class convertible:
    get_indicators = GetIndicators().get_indicators
    get_cash_flow = GetCashFlow().get_cash_flow


from phoenixc.services.subscribe import Subscribe
sub_instance =Subscribe()
sub = sub_instance.sub
unsub = sub_instance.unsub
start = sub_instance.start
stop = sub_instance.stop

from phoenixc.services.quote_sub import QuoteSubscribe
quote_sub_instance = QuoteSubscribe()
subscribe_market_data = quote_sub_instance.subscribeMarketData
subscribe_entrust = quote_sub_instance.subscribeEntrust
subscribe_trade = quote_sub_instance.subscribeTrade
unsubscribe_market_data = quote_sub_instance.unsubscribeMarketData
unsubscribe_entrust = quote_sub_instance.unsubscribeEntrust
unsubscribe_trade = quote_sub_instance.unsubscribeTrade

