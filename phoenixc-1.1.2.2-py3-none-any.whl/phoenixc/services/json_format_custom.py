"""
-*- coding: utf-8 -*-
@Time : 2024
"""
from google.protobuf import json_format


class JsonFormatCustomPrinter(json_format._Printer):

    def _FieldToJsonObject(self, field, value):
        """Converts field value according to Proto3 JSON Specification."""
        if field.cpp_type == json_format.descriptor.FieldDescriptor.CPPTYPE_MESSAGE:
            return self._MessageToJsonObject(value)
        elif field.cpp_type == json_format.descriptor.FieldDescriptor.CPPTYPE_ENUM:
            if self.use_integers_for_enums:
                return value
            if field.enum_type.full_name == 'google.protobuf.NullValue':
                return None
            enum_value = field.enum_type.values_by_number.get(value, None)
            if enum_value is not None:
                return enum_value.name
            else:
                if field.enum_type.is_closed:
                    raise json_format.SerializeToJsonError('Enum field contains an integer value '
                                               'which can not mapped to an enum value.')
                else:
                    return value
        elif field.cpp_type == json_format.descriptor.FieldDescriptor.CPPTYPE_STRING:
            if field.type == json_format.descriptor.FieldDescriptor.TYPE_BYTES:
                # Use base64 Data encoding for bytes
                return json_format.base64.b64encode(value).decode('utf-8')
            else:
                return value
        elif field.cpp_type == json_format.descriptor.FieldDescriptor.CPPTYPE_BOOL:
            return bool(value)
        elif field.cpp_type in json_format._INT64_TYPES:
            return value
        elif field.cpp_type in json_format._FLOAT_TYPES:
            if json_format.math.isinf(value):
                if value < 0.0:
                    return json_format._NEG_INFINITY
                else:
                    return json_format._INFINITY
            if json_format.math.isnan(value):
                return json_format._NAN
            if field.cpp_type == json_format.descriptor.FieldDescriptor.CPPTYPE_FLOAT:
                if self.float_format:
                    return float(format(value, self.float_format))
                else:
                    return json_format.type_checkers.ToShortestFloat(value)

        return value

json_format._Printer = JsonFormatCustomPrinter
