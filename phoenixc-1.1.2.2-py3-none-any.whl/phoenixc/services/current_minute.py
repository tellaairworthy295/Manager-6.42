"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


class CurrentMinute(Basic):
    def current_minute(self, unified_code):
        """获取最近的分钟线数据
        :param unified_code:合约代码,String/List格式
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        response = client.current_minute(
            price_pb2.ReqCurrentMinuteParams(unified_code=unified_code),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            return response_df
