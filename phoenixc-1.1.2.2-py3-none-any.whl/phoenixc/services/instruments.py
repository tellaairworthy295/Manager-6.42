"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import  json_format_custom
from phoenixc import init_instance
from phoenixc.common import instruments_pb2, instruments_pb2_grpc
from phoenixc.services.basic import Basic


class Instrument(object):
    def __init__(self, d):
        self.__dict__ = d

    def __repr__(self):
        return f"Instrument({self.__dict__})"


def instruments(unified_code, market="cn"):
    """获取某个国家市场内一个或者多个合约最新的详细信息。目前仅支持中国市场。支持查询的合约类型包括：个股、指数、基金、期货、期权、现货、债券和回购
    :param unified_code:合约代码,String/List格式
    :param market:地区代码,如 "cn" (Default value = "cn")
    :return:Instrument Object或Instrument Object列表
    """
    Basic().is_initialized(init_instance.metadata)
    unified_code, len_unified_code = Basic().format_unified_code(unified_code)
    client = instruments_pb2_grpc.InstrumentServiceStub(init_instance.channel)
    response = client.instruments(
        instruments_pb2.ReqInstrumentsParams(unified_code=unified_code, market=market),
        metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        result_list = []
        for field in response.DESCRIPTOR.fields:
            if len(getattr(response, field.name)) != 0:
                field_name, columns_list, date_columns_list = Basic().get_data_list(field)
                one_type_data = pd.DataFrame(response_dict[field_name], columns=columns_list)
                if len(date_columns_list) != 0:
                    for i in date_columns_list:
                        one_type_data[i] = pd.to_datetime(one_type_data[i], format="ISO8601").dt.tz_localize(None)  # 处理日期格式
                [result_list.append(Instrument(one_type_data.iloc[j].to_dict())) for j in range(len(one_type_data))]
            else:
                continue
        if len_unified_code == 1:
            return result_list[0]
        return result_list
