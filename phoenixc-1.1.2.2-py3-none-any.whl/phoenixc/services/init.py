"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import grpc
import hashlib
import base64
from phoenixc._version import get_versions
from concurrent.futures import ThreadPoolExecutor
from phoenixc.common.PhoenixSubClient import PhoenixSubClient
from phoenixc.services.user_login import user_login


class Init(object):

    def __init__(self):
        self.metadata = None
        self.channel = None
        self.username = None
        self.addr = None

    def init(self, username, password, addr=(None, None), max_send_message_length=256 * 1024 * 1024,
             max_receive_message_length=256 * 1024 * 1024):
        """
        :param username: string
        :param password: string
        :param addr: (host, port) = ("172.0.0.1", 80)
        :param max_send_message_length: Default value = 256 * 1024 * 1024
        :param max_receive_message_length: Default value = 256 * 1024 * 1024
        :return:
        """
        self.username = username
        self.addr = addr[0]+":"+str(addr[1])
        md5_hash = hashlib.md5()
        md5_hash.update(password.encode('utf-8'))
        password_encryption = md5_hash.hexdigest()
        authorization = f"{username}:{password_encryption}"
        authorization_base64 = base64.b64encode(authorization.encode()).decode()
        import socket
        laddr = "undefined"
        with socket.socket() as c:
            c.connect(addr)
            laddr = c.getsockname()

        self.channel = grpc.insecure_channel(addr[0] + ":" + str(addr[1]),
                                             options=[('grpc.max_send_message_length', max_send_message_length),
                                                      ('grpc.max_receive_message_length', max_receive_message_length)])
        self.metadata = (("authorization", "Basic " + authorization_base64),("sdk_version", "python@"+get_versions()),
                         ("client_addr", f"{laddr[0]}:{laddr[1]}"))
        self.login(username, password_encryption)
    
    def login(self, user_name:str, password:str, auth_info:str = None):
        try:
            resp = user_login(grpc_channel=self.channel, grpc_metadata= self.metadata, user_name=user_name, password=password, auth_info=auth_info)
        except grpc.RpcError as rpc_error:
            raise rpc_error
            #error_code = rpc_error.code()
            #if error_code == grpc.StatusCode.UNAVAILABLE:
            #    raise RuntimeError( 400, "login failed, server is unavailable.")
            #elif error_code == grpc.StatusCode.PERMISSION_DENIED:
            #    raise RuntimeError( 403, "login failed, permission_denied.")
            #elif error_code == grpc.StatusCode.UNAUTHENTICATED:
            #    raise RuntimeError(401, "login failed, no route for authencate.")
            #else:
            #    #print(f"Received RPC error: code={rpc_error.code()} message={rpc_error.details()}")
            #    raise RuntimeError( 405, "login failed, please check the username or password.")

    def info(self):
        """
        :return: 打印账户信息
        """
        if self.metadata is None:
            print("phoenixc is not initialized")
        else:
            print("phoenixc version: {}".format(get_versions()))
            print("server address: {}".format(self.addr))
            print("You are using account: {}".format(self.username))
