import phoenixc
from phoenixc.services.basic import Basic
import phoenixc.common.PhoenixSubClient as PhoenixSubClient
from concurrent.futures import ThreadPoolExecutor
import logging


class Subscribe(Basic):
    def __init__(self) -> None:
        self._instanse = None
        super().__init__()

    def init(self):
        if self._instanse != None:
            return
        self._instanse = PhoenixSubClient.PhoenixSubClient(ThreadPoolExecutor(), 
                                                           phoenixc.init_instance.addr, 
                                                           phoenixc.init_instance.channel, 
                                                           phoenixc.init_instance.metadata,
                                                           log_level=logging.INFO)

    def sub(self, sub_type:str, topic:str, tag:str, msg_handler, sub_option:dict = None, client_context:any = None):
        self.init()
        self._instanse.sub(sub_type, topic, tag, msg_handler, sub_option, client_context)

    def unsub(self, unsub_type:str, topic:str, tag:str):
        self.init()
        self._instanse.unsub(unsub_type, topic, tag)

    def start(self):
        self.init()
        self._instanse.start()
    
    def stop(self):
        self.init()
        self._instanse.stop()