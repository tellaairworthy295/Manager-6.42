"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import datetime
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import calendar_pb2, calendar_pb2_grpc
from phoenixc.services.basic import Basic


def get_trading_dates(start_date, end_date=None, exchange="SH"):
    """获取交易日列表
    :param start_date:YYYY-MM-DD
    :param end_date:结束日期,默认今天(Default value = None),YYYY-MM-DD
    :param exchange:交易所代码 (Default value = "SH")
    :return:日历列表
    """
    Basic().is_initialized(init_instance.metadata)
    start_date = Basic().check_date(start_date)
    if end_date is not None:
        end_date = Basic().check_date(end_date)
    client = calendar_pb2_grpc.CalendarServiceStub(init_instance.channel)
    response = client.get_trading_dates(
        calendar_pb2.ReqGetTradingDatesParams(start_date=start_date, end_date=end_date, exchange=exchange), metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        return list(map(change_date, list(response_dict.values())[0]))

def change_date(date):
    return datetime.datetime.strptime(date["trading_date"], "%Y-%m-%d").date()
