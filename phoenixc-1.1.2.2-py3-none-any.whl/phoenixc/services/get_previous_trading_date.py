"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import datetime
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import calendar_pb2, calendar_pb2_grpc
from phoenixc.services.basic import Basic


def get_previous_trading_date(date, n=1, exchange="SH"):
    """获取历史某个交易日,默认获取指定日期的上一交易日
    :param date:YYYY-MM-DD
    :param n:代表往前第 n 个交易日。默认为 1，即前一个交易日
    :param exchange:交易所代码 (Default value = "SH")
    :return: datetime.date
    """
    Basic().is_initialized(init_instance.metadata)
    date = Basic().check_date(date)
    client = calendar_pb2_grpc.CalendarServiceStub(init_instance.channel)
    response = client.get_previous_trading_date(
        calendar_pb2.ReqGetPreviousTradingDateParams(date=date, n=n, exchange=exchange), metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        return datetime.datetime.strptime(response_dict["trading_date"], "%Y-%m-%d").date()
