from services.quote_sub_defs import *
import phoenixc as ph


#topic item manager
class QuoteSubscribeTopicManager():
    def __init__(self) -> None:
        self._topic_def:map[str][list[QuoteSubscribeTopic]] =  {}
        self._sdk_sub_handlers_map = {}
        topics = QuoteSubscribeTopicKeyDef()
        self.add_topic_def(topics.ALL_MARKET, OptionSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, IndexSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, CSISubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, BondSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, ActualSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, FutureSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, HKSubTopic(topics.ALL_MARKET))
        self.add_topic_def(topics.ALL_MARKET, SpotSubTopic(topics.ALL_MARKET))

        self.add_topic_def(topics.MARKET, OptionSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, IndexSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, CSISubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, BondSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, ActualSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, FutureSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, HKSubTopic(topics.MARKET))
        self.add_topic_def(topics.MARKET, SpotSubTopic(topics.MARKET))
        
        self.add_topic_def(topics.TICKBYTICK_TRADE, TradeSubTopic(topics.TICKBYTICK_TRADE))
        self.add_topic_def(topics.TICKBYTICK_ENTRUST, EntrustSubTopic(topics.TICKBYTICK_ENTRUST))
        self.add_topic_def(topics.ALL_TICKBYTICK, TradeSubTopic(topics.ALL_TICKBYTICK))
        self.add_topic_def(topics.ALL_TICKBYTICK, EntrustSubTopic(topics.ALL_TICKBYTICK))
        self.add_topic_def(topics.TEST, TestSubTopic(topics.TEST))
     

    def _merge_and_deduplicate(self, list1, list2, *args):
        merged_set = set(list1 + list2 + args)
        return [element for element in merged_set]

    def add_topic_def(self, topic_key:str, topic_relative_table:str, sub_options:dict = None, client_context = None):
        subscribe_def_obj = QuoteSubscribeTopic(topic_key, 
                                      topic_relative_table, 
                                      sub_options, 
                                      client_context)
        self.add_topic_def(subscribe_def_obj)

    def add_topic_def(self, topic_key:str, topic_def_obj:QuoteSubscribeTopic):
        if topic_key not in self._topic_def.keys():
            self._topic_def[topic_key] = [topic_def_obj]
        else:
            self._topic_def[topic_key].append(topic_def_obj)        

    def sub_topic(self, topic:str, tag:str, handler, api_sub_options:dict = None):
        sub_id = f"{topic}-{tag}"
        if sub_id in self._sdk_sub_handlers_map.keys() \
           and handler == self._sdk_sub_handlers_map[sub_id]:
            raise  RuntimeError(f"{handler} is already subscribe by {sub_id}")
        #find relative stream tables for topic
        if topic not in self._topic_def.keys():
            raise RuntimeError(f"{topic} not defined")

        topic_def:list[QuoteSubscribeTopic] = self._topic_def[topic]
        for topic_item in topic_def:
            sub_type = topic_item.topic
            tb_name = topic_item.table_name
            client_context = topic_item.client_context
            sub_options = topic_item.sub_options
            if api_sub_options is not None:
                sub_options.update(api_sub_options)
            ph.sub(sub_type, tb_name, tag, handler, sub_options, client_context)
        self._sdk_sub_handlers_map[sub_id] = handler
        ph.start()
    

    def unsub_topic(self, topic:str, tag:str):
        sub_id = f"{topic}-{tag}"
        if sub_id not in self._sdk_sub_handlers_map.keys():
            return
        
        if topic not in self._topic_def.keys():
            raise f"{topic} not defined"
        topic_defs:list[QuoteSubscribeTopic] = self._topic_def[topic]
        for topic_item in topic_defs:
            ph.unsub(topic_item.topic, topic_item.table_name, tag)
        del self._sdk_sub_handlers_map[sub_id]

class QuoteSubscribe():
    def __init__(self) -> None:
        self._sub_mgr = QuoteSubscribeTopicManager()
        self._topic_keys = QuoteSubscribeTopicKeyDef()

    
    def subscribeTest(self, handler):
        self._sub_mgr.sub_topic(self._topic_keys.TEST, 
                                "test", 
                                handler,api_sub_options={"filter":["AU9999.SGE"]})
    
    def UnsubscribeTest(self):
        self._sub_mgr.unsub_topic(self._topic_keys.TEST, 
                                "test")

    #当客户端与行情后台通信连接断开时，该方法被调用。
    #@param reason 错误原因，请与错误代码表对应
    #@remark api不会自动重连，当断线发生时，请用户自行选择后续操作。可以在此函数中调用Login重新登录。注意用户重新登录后，需要重新订阅行情
    #void OnDisconnected(int reason)
    def OnDisconnected(self, handler):
        """ 当前回调接口暂不支持

        Args:
            handler (_type_): _description_
        """        
        pass
    
    #错误应答
    #@param error_info 当服务器响应发生错误时的具体的错误代码和错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
    #@remark 此函数只有在服务器发生错误时才会调用，一般无需用户处理
    #void OnError(XTPRI *error_info)
    def OnError(self, handler):
        """当前回调接口暂不支持

        Args:
            handler (_type_): _description_
        """        
        pass
    
    #订阅行情应答，包括股票、指数和期权
    #@param ticker 详细的合约订阅情况
    #@param error_info 订阅合约发生错误时的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
    #@param is_last 是否此次订阅的最后一个应答，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
    #@remark 每条订阅的合约均对应一条订阅应答，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
    #void OnSubMarketData(XTPST *ticker, XTPRI *error_info, bool is_last)
    def subscribeMarketData(self, tag:str, tickers:list, handler):
        """市场行情快照订阅（分标的订阅，支持1个或多个行情标的订阅）

        Args:
            tickers (list): 行情标的列表，样例：["000001.SZ","000001.SH","600918.SH"]
            tag (str) ：订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            handler (_type_): 接收到的每一条订阅消息的回调函数，handler的定义如下：
                      def handler(clientid, topic, tag, msg, msg_context)
                      
                      Args:
                        clientid (str): 订阅客户端标识，由sdk自动生成，区分每个订阅多进程或多线程
                        topic (str): 订阅主题区分，当前包括MARKET（按标的订阅），ALLMARKET（全市场订阅），
                                                        TICKBYTICK（按标的逐步），ALLTICKBYTICK（全市场逐笔）四类取值

                        tag (str): 订阅标签，由客户端订阅的时候给出的标识符，作为对多次订阅动作的区分标识，用于对应的unsub。

                        msg (dict): 接收到的订阅消息，是一个dict类型，注意，每一类消息的key的集合不同，样例如下：
                                    sseCsiStream： {
                                                    'unified_code': 'H11050.CSI', 
                                                    'volume': 67835296, 
                                                    'open': 1599.923, 
                                                    'close': 0.0, 
                                                    'high': 1599.923, 
                                                    'low': 1573.098, 
                                                    'last': 1577.0599, 
                                                    'total_turnover': 64677.275, 
                                                    'pre_close': 1602.6105, 
                                                    'change_rate': -0.0159, 
                                                    'data_time': datetime.datetime(2024, 7, 8, 10, 47, 27)
                                                    }
                                    xtpBondStream: {
                                                    'asks': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 
                                                    'ask_vols': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
                                                    'bids': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], 
                                                    'bid_vols': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
                                                    'unified_code': '147009.SH', 
                                                    'data_time': datetime.datetime(2024, 7, 8, 10, 47, 34, 205000), 
                                                    'open': 0.0, 'close': 0.0, 'high': 0.0, 'low': 0.0, 'last': 0.0, 
                                                    'limit_up': 0.0, 'limit_down': 0.0, 'total_turnover': 0.0, 
                                                    'volume': 0, 'pre_close': 100.0, 'change_rate': -1.0, 
                                                    'status': None
                                                    }

                        msg_context (dict): 由订阅服务端返回的对于本次msg的额外的描述信息，样例如下：
                                            msg_context["table_name"]（str）: 描述msg来自于源表的名字

                                            msg_context["column_filter"]（list）：描述msg的所有的key的构成
            tickers (list[str]) : 一个过滤列表，元素可以为如下取值：
                                    1、通配符 *，表示获取全市场所有标的的行情快照
                                    2、市场代码 （取值如“SZ”，“SH”,"HK", "NQ", "SGE"）等
                                    3、标的代码 （取值如“000001.SZ“, "600918.SH"）等
                                    示例：
                                    1、订阅全市场行情： ["*"]
                                    2、订阅深圳市场行情： ["SZ"]
                                    3、订阅深圳和上海市场行情：[”SZ“, "SH"]
                                    4、订阅多个标的行情：[“000001.SZ“, "600918.SH"]
                                    5、订阅深圳市场行情，以及上海单个标的行情：["SZ"，"600918.SH"]
        """        
        self._sub_mgr.sub_topic(self._topic_keys.MARKET, 
                                tag, 
                                handler,
                                {"filter": tickers})
    
    #退订行情应答，包括股票、指数和期权
    #@param ticker 详细的合约取消订阅情况
    #@param error_info 取消订阅合约时发生错误时返回的错误信息，当error_info为空，或者error_info.error_id为0时，表明没有错误
    #@param is_last 是否此次取消订阅的最后一个应答，当为最后一个的时候为true，如果为false，表示还有其他后续消息响应
    #@remark 每条取消订阅的合约均对应一条取消订阅应答，需要快速返回，否则会堵塞后续消息，当堵塞严重时，会触发断线
    #void OnUnSubMarketData(XTPST *ticker, XTPRI *error_info, bool is_last)
    def unsubscribeMarketData(self, tag:str, tickers:list= None):
        """ 取消对于市场快照行情的按标的订阅，

        Args:
            tag (str) :订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            tickers (list): 要取消的按标的订阅的标的列表。

            PS:订阅和取消订阅以tag作为标识
        """        
        self._sub_mgr.unsub_topic(self._topic_keys.MARKET, 
                                  tag
                                  )

    def subscribeEntrust(self, tag:str, tickers:list, handler):
        """逐笔行情委托按标的列表订阅

        Args:
            tag (str) :订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            tickers (list): 订阅标的列表
            handler (_type_): 与subscribeMarketData中的handler回调函数定义一致；
        """        
        self._sub_mgr.sub_topic(self._topic_keys.TICKBYTICK_ENTRUST, 
                                tag, 
                                handler,
                                {"filter":tickers})
    
    def unsubscribeEntrust(self, tag:str, tickers:list = None):
        """取消逐笔委托按标的列表订阅

        Args:
            tag (str) :订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            tickers (list): 要取消的按标的订阅的标的列表。
        """        
        self._sub_mgr.unsub_topic(self._topic_keys.TICKBYTICK_ENTRUST, tag)


    def subscribeTrade(self, tag:str, tickers:list, handler):
        """逐笔行情委托按标的列表订阅

        Args:
            tag (str) :订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            tickers (list): 订阅标的列表
            handler (_type_): 与subscribeMarketData中的handler回调函数定义一致；
        """        
        self._sub_mgr.sub_topic(self._topic_keys.TICKBYTICK_TRADE, 
                                tag, 
                                handler,
                                {"filter":tickers})
    
    def unsubscribeTrade(self, tag:str, tickers:list = None):
        """取消逐笔委托按标的列表订阅

        Args:
            tag (str) :订阅标签，由客户端订阅的时候给出的标识符,调用方需保证该tag在本进程内唯一
            tickers (list): 要取消的按标的订阅的标的列表。
        """        
        self._sub_mgr.unsub_topic(self._topic_keys.TICKBYTICK_TRADE, tag)