"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import datetime


class Basic(object):

    @staticmethod
    def get_data_list(field):
        """
        获取response里field数据列表的名称、所有字段名列表、时间戳格式的字段名列表
        :return: 一个str,两个list
        """
        field_name = field.name
        columns_list = field.message_type.fields_by_name.keys()
        date_columns_list = [i for i in columns_list if
                             field.message_type.fields_by_name[i].message_type is not None and
                             field.message_type.fields_by_name[i].message_type.name == "Timestamp"]
        return field_name, columns_list, date_columns_list

    @staticmethod
    def format_time_slice(time_slice):
        """
        格式化time_slice,并对其格式进行校验
        :param time_slice: str
        :return:
        """
        if time_slice is None:
            time_slice = time_slice
        elif type(time_slice)==str and len(time_slice.split(','))==2:
            if not all(not s for s in time_slice.split(',')):
                time_slice = time_slice.split(',')
            else:
                time_slice = None
        elif type(time_slice)==tuple and len(time_slice) == 2:
            time_slice_list = []
            for i in range(len(time_slice)):
                if type(time_slice[i]) == str:
                    time_slice_list.append(time_slice[i])
                elif type(time_slice[i]) == datetime.time:
                    time_slice_list.append(time_slice[i].strftime("%H:%M:%S.%f"))
                elif time_slice[i] is None:
                    time_slice_list.append("")
            if time_slice_list[0]==time_slice_list[1]=="":
                time_slice = None
            else:
                time_slice = time_slice_list
        else:
            raise ValueError("invalid time_slice: {}, None, str, or tuple(str,str)/tuple(datetime.time,datetime.time) "
                             "and length=2, at least specify hours,eg:('HH:MM:SS.sss','HH:MM:SS.sss')".format(time_slice))
        if time_slice is not None:
            for time in time_slice:
                if time != "":
                    try:
                        datetime.datetime.strptime(time, "%H")
                    except ValueError:
                        try:
                            datetime.datetime.strptime(time, "%H:%M")
                        except ValueError:
                            try:
                                datetime.datetime.strptime(time, "%H:%M:%S")
                            except ValueError:
                                try:
                                    datetime.datetime.strptime(time, "%H:%M:%S.%f")
                                except ValueError:
                                    raise ValueError("invalid time_slice: {}, The time format needs to be:'HH:MM:SS.sss', at least specify hours".format(time))
            time_slice = time_slice[0] + "," + time_slice[1]
        return time_slice

    @staticmethod
    def format_unified_code(unified_code):
        """
        格式化unified_code，使之支持list
        :param unified_code:
        :return:
        """
        if type(unified_code) == str:
            unified_code = unified_code
            len_unified_code = 1
        elif type(unified_code) == list:
            len_unified_code = len(unified_code)
            unified_code = ','.join(unified_code)
        else:
            raise ValueError(
                "invalid unified_code: {}, The format needs to be: str/list".format(unified_code))
        return unified_code, len_unified_code

    @staticmethod
    def check_date(one_date):
        """
        校验日期格式
        :param one_date:一个日期
        :return: 如果不满足YYYY-MM-DD,给予提示
        """
        try:
            datetime.datetime.strptime(one_date, "%Y-%m-%d")
            return one_date
        except ValueError:
            raise ValueError("invalid date: {}, The date format needs to be: 'YYYY-MM-DD'".format(one_date))

    @staticmethod
    def check_time(one_time):
        """
        校验时间格式
        :param one_time:一个时间
        :return: "YYYY-MM-DD HH:MM:SS.sss",至少为"YYYY-MM-DD"
        """
        try:
            datetime.datetime.strptime(one_time, "%Y-%m-%d")
        except ValueError:
            try:
                datetime.datetime.strptime(one_time, "%Y-%m-%d %H")
            except ValueError:
                try:
                    datetime.datetime.strptime(one_time, "%Y-%m-%d %H:%M")
                except ValueError:
                    try:
                        datetime.datetime.strptime(one_time, "%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        try:
                            datetime.datetime.strptime(one_time, "%Y-%m-%d %H:%M:%S.%f")
                        except ValueError:
                            raise ValueError(
                                "invalid time_slice: {}, The time format needs to be:'YYYY-MM-DD HH:MM:SS.sss', at least specify YYYY-MM-DD".format(
                                    one_time))
        return one_time

    @staticmethod
    def is_initialized(metadata):
        if metadata is None:
            raise RuntimeError("phoenixc is not initialized")

    @staticmethod
    def format_param(param):
        """
        格式化param
        :param param:str/list
        :return:
        """
        if type(param) == str:
            factor = param
        elif type(param) == list:
            factor = ','.join(param)
        else:
            raise ValueError(
                "invalid parameter: {}, The format needs to be: str/list".format(param))
        return factor

    @staticmethod
    def change_date(date):
        return datetime.datetime.strptime(date, "%Y-%m-%d").date()