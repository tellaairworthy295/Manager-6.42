"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
import numpy as np
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import bond_pb2, bond_pb2_grpc
from phoenixc.services.basic import Basic


class GetYieldCurve(Basic):
    def get_yield_curve(self, start_date, end_date, tenor=None, market='cn', curve_code="1232"):
        """获取某个国家市场在一段时间内收益率曲线水平（包含起止日期）。目前仅支持中国市场。
        :param start_date:开始日期，YYYY-MM-DD
        :param end_date:结束日期，YYYY-MM-DD
        :param tenor:str or list标准期限，'0S'-隔夜，'1M'-1个月，'1Y'-1年，等等
        :param market:默认是中国市场('cn')，目前支持中国市场。
        :param curve_code:中债登发布的曲线编码，默认为1232-中债国债收益率曲线到期收益率
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        start_date = self.check_date(start_date)
        end_date = self.check_date(end_date)
        if tenor is not None:
            tenor = self.format_param(tenor)
        client = bond_pb2_grpc.BondServiceStub(init_instance.channel)
        response = client.get_yield_curve(
            bond_pb2.ReqGetYieldCurveParam(start_date=start_date, end_date=end_date, tenor=tenor, market=market,
                                           curve_code=curve_code),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            result_sorted = response_df.sort_values(by=["trade_date"])
            tenor_list = sorted(list(set(result_sorted.tenor.tolist())), key=self.time_to_months)
            result_sorted["tenor"] = pd.Categorical(result_sorted["tenor"], categories=tenor_list, ordered=True)
            result_sorted_final = result_sorted.sort_values(by="tenor")
            result = pd.pivot(result_sorted_final, values="yield_value", index=["trade_date"], columns=["tenor"])
            result.columns = result.columns.values
            result.reset_index(inplace=True)
            result_final = result.set_index(["trade_date"], drop=True)
            return result_final

    @staticmethod
    def time_to_months(time_str):
        """
        将时间字符串转换为月数。
        :param time_str:str
        :return:
        假设：
        'YS' 表示年，'MS' 表示月，'S' 表示秒（这里假设'0S'为最小，放在最前面）
        """
        if time_str.endswith("Y"):
            return int(time_str[:-1]) * 12  # 年转换为月
        elif time_str.endswith("M"):
            return int(time_str[:-1])  # 月保持不变
        elif time_str == "0S":
            return 0  # 特殊处理"0S"
        else:
            raise ValueError(f"Unknown time format: {time_str}")
