"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import datetime
from phoenixc.services import json_format_custom
from phoenixc.common import phoenix_pb2, phoenix_pb2_grpc
from phoenixc.services.basic import Basic


def user_login(grpc_channel, grpc_metadata, user_name:str, password:str, auth_info:str = None):
    """校验用户名和密码

    Args:
        username (str): _description_
        password (str): _description_
        auth_info (str, optional): _description_. Defaults to None.

    Returns:
        _type_: _description_
    """
    Basic().is_initialized(grpc_metadata)
    client = phoenix_pb2_grpc.PhoenixServiceStub(grpc_channel)
    response = client.user_login(
        phoenix_pb2.ReqUserLoginParams(user_name=user_name, password=password, auth_info=auth_info), metadata=grpc_metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        return response_dict
