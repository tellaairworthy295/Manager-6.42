import functools
import numpy
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

class QuoteSubscribeTopicKeyDef():
    def __init__(self) -> None:
        self.CHINA = "CHINA"
        self.NEEQ = "NEEQ"
        self.HK = "HK"
        self.BOND = "BOND"
        self.INDEX = "INDEX"
        self.FUTURE = "FUTURE"
        self.FUTURE_IF = "FUTURE_IF"
        self.FUTURE_BOND = "FUTURE_BOND"
        self.OPT = "OPT"
        self.SPOT = "SPOT"
        self.MARKET = "MARKET"
        self.ALL_MARKET = "ALLMARKET"
        self.TICKBYTICK = "TICKBYTICK"
        self.TICKBYTICK_ENTRUST = "TICKBYTICK_ENTRUST"
        self.TICKBYTICK_TRADE = "TICKBYTICK_TRADE"
        self.ALL_TICKBYTICK = "ALLTICKBYTICK"
        self.TEST = "TEST"


class SubClientLocalContext(): 
    def __init__(self) -> None:
        # msg_adapter:a func with the def below
        # def msg_adapter(msg, msg_context, client_local_context):
        #     pass
        self.msg_adapter:function = None

        # msg_column_transformer dict, define the lambda to transform the column object
        # the key is column, the value is the lambda function definition
        # eg.
        # self.msg_column_transformer["data_time"] = lambda x:x.strftime("%Y-%m-%d")
        # will transform the data_time column from datetime to a str lik "2024-06-18"
        self.msg_column_transformer:dict[str][function] = {}

        # the column_rename mechnism,
        # eg.
        #[("col_a", "col_b"), ("col_a", "col_c")]
        self.msg_column_rename:list[(str, str)] = []

        # calc the column names and the relate value indexs in the msg
        # calced by PhoenixSubClient::sub after the server return the response.
        self.msg_column_name_and_index:dict[str][int] = {}

        # clear the column that need to be remove
        self.msg_clear_columns:list = []

#g_wrong_ndigits = {}
def msg_default_adapter(msg, msg_context:dict, client_local_context:SubClientLocalContext):
    """transfer the msg to proper format before passing it to the userdef handler

    Args:
        msg (list|any): the msg return from api-server(stream table elements, commonly be list)

        msg_context (dict): the dict has the below structure:
                            msg_context["table_name"] = topic

                            msg_context["action_name"] = tag

                            msg_context["sub_options"] = sub_options_dict (the extra options used by sub* apis)

                            msg_context["column_filter"] = column_filter (all the columns names return by api-server)

        client_local_context(SubClientLocalContext):
    """
    msg_after_process = {}
    column_name_and_index = client_local_context.msg_column_name_and_index
    
    #unified_code_index = column_names.index("unified_code")
    #global g_wrong_ndigits

    for col_name_new, value_index_in_msg in column_name_and_index.items():
        if value_index_in_msg is None:
            msg_after_process[col_name_new] = None
            continue
        if isinstance(msg[value_index_in_msg], numpy.ndarray):
            msg_after_process[col_name_new] = msg[value_index_in_msg].tolist()
        elif isinstance(msg[value_index_in_msg], numpy.datetime64):
            """
            Converts a numpy datetime64 object to a python datetime object 
            Input:
            date - a np.datetime64 object
            Output:
            DATE - a python datetime object
            """
            np_datetime = msg[value_index_in_msg]
            timestamp_temp = ((np_datetime - numpy.datetime64('1970-01-01T00:00:00'))
                        / numpy.timedelta64(1, 's'))
            msg_after_process[col_name_new] = datetime.fromtimestamp(timestamp_temp) - timedelta( hours= 8)
        else:
            msg_after_process[col_name_new] = msg[value_index_in_msg]
        
        #check the number float wrong ndigits
        #id = f"{msg_context['table_name']}.{col_name}"
        #if( isinstance(msg[i], float) ):
        #    decimal_part = str(msg[i]).split('.')[1]
        #    if(len(decimal_part) > 4):
        #        if id not in g_wrong_ndigits.keys():
        #            print(f"float ndigits wrong:{id}({msg[i]}), code={msg[unified_code_index]}")
        #            g_wrong_ndigits[id] = msg[i]
        #if( isinstance(msg[i], numpy.ndarray) ):
        #    #iter by row first
        #    list_numbers = msg[i].tolist()
        #    for x in list_numbers:
        #        numpy_split_ret = str(x).split('.')
        #        if(len(numpy_split_ret) == 1):
        #            #the str is "0."
        #            continue
        #        decimal_part = numpy_split_ret[1]
        #        if(len(decimal_part) > 4):
        #            if id not in g_wrong_ndigits.keys():
        #                print(f"float ndigits wrong(ndarray):{id}({x} type:{type(x)}), code={msg[unified_code_index]}")
        #                g_wrong_ndigits[id] = msg[i]
        #                break

    #handle the column rename
    
    return msg_after_process

#topic item
class QuoteSubscribeTopic():
    def  __init__(self, topic_key:str, topic_relative_table:str, sub_options:dict = None, client_context = None) -> None:
        self.topic = topic_key
        self.table_name = topic_relative_table
        self.sub_options = sub_options
        self.client_context = client_context

    def decimal_round(self, number_obj:float, ndigits:int):
        number_split_ret = str(number_obj).split('.')
        if(len(number_split_ret) == 1):
            return number_obj
        
        decimal_part = number_split_ret[1]
        if(len(decimal_part) <= ndigits):
            return number_obj
    
        d = Decimal(str(number_obj))
        str_ndigits_decimal = "0." + "".join(["0" for i in range(0,ndigits)])
        d_after_round = d.quantize(Decimal(str_ndigits_decimal), rounding=ROUND_HALF_UP)
        return float(d_after_round)


    def round_number(self, number_obj:float, data_all:dict, ndigits:int):
        #round(2.675, 2)
        if(isinstance(number_obj, list)):
            return [self.decimal_round(x, ndigits) for x in number_obj]
        elif(isinstance(number_obj, numpy.ndarray)):
            list_numbers = number_obj.tolist()
            return [self.decimal_round(x, ndigits) for x in list_numbers]
        elif number_obj is None:
            return number_obj
        elif isinstance(number_obj, float):
            return self.decimal_round(number_obj, ndigits)
        else:
            return number_obj


class OptionSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpOptionStream"
        self.sub_options = {"column_filter":["ask_price", "ask_volume", "bid_price", 
                                             "bid_volume", "unified_code", "data_time", 
                                             "open_price", "close_price", "high_price", 
                                             "low_price", "last_price", "upper_limit_price",
                                             "lower_limit_price", "turnover", "volume", 
                                             "pre_close_price", "settlement_price", "change_rate", 
                                             "pre_settlement_price", "ticker_status"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("upper_limit_price", "limit_up"),
                                     ("lower_limit_price", "limit_down"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("settlement_price", "settlement"),
                                     ("pre_settlement_price", "pre_settlement"),
                                     ("ticker_status", "status")
                                     ]

        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_down"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_up"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["settlement"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_settlement"] = functools.partial(self.round_number, ndigits=4)
        self.client_context = context

class IndexSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpIndexStream"
        self.sub_options = {"column_filter":["unified_code", "data_time", "open_price", 
                                             "close_price", "high_price", "low_price", 
                                             "last_price", "turnover", "volume", 
                                             "pre_close_price", "change_rate"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close")
                                     ]

        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        self.client_context = context

class CSISubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "sseCsiStream"
        self.sub_options = {"column_filter":["unified_code", "volume",
                                             'open_price', 'close_price', 
                                             'high_price', 'low_price', 
                                             'last_price', 'turnover', 
                                             'pre_close_price', 'change_rate',
                                             'unified_code', 'data_time',
                                             'volume', 'pre_close_price']}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close")
                                     ]
        
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        

        self.client_context = context

class BondSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpBondStream"
        self.sub_options = {"column_filter":["ask_price", "ask_volume", "bid_price", 
                                             "bid_volume", "unified_code", "data_time", 
                                             "open_price", "close_price", "high_price", 
                                             "low_price", "last_price", "upper_limit_price", 
                                             "lower_limit_price", "turnover", "volume", 
                                             "pre_close_price", "change_rate", "ticker_status"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("upper_limit_price", "limit_up"),
                                     ("lower_limit_price", "limit_down"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("ticker_status", "status")
                                     ]

        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_up"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_down"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        self.client_context = context


class ActualSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpStockStream"
        self.sub_options = {"column_filter":["ask_price", "ask_volume", "bid_price", 
                                             "bid_volume", "unified_code", "data_time", 
                                             "open_price", "close_price", "high_price", 
                                             "low_price", "last_price", "upper_limit_price", 
                                             "lower_limit_price", "turnover", "volume", 
                                             "pre_close_price", "pre_iopv", "change_rate", 
                                             "iopv", "ticker_status"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("upper_limit_price", "limit_up"),
                                     ("lower_limit_price", "limit_down"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("ticker_status", "status")
                                     ]

        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_down"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_up"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["iopv"] = functools.partial(self.round_number, ndigits=6)
        context.msg_column_transformer["pre_iopv"] = functools.partial(self.round_number, ndigits=6)
        self.client_context = context

def ctp_data_time_combine(data_time_obj, all_data):
    time_obj = data_time_obj
    date_obj = all_data["action_date"]
    return date_obj + timedelta( hours=time_obj.hour, 
                                      minutes=time_obj.minute, 
                                      seconds=time_obj.second,
                                      milliseconds=time_obj.microsecond/1000 )

class FutureSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "ctpMarketStream"
        self.sub_options = {"column_filter":["action_date", "data_time", "ask_price", 
                                             "ask_volume", "bid_price", "bid_volume", 
                                             "unified_code", "open_price", "close_price", 
                                             "high_price", "low_price", "last_price", 
                                             "upper_limit_price", "lower_limit_price", 
                                             "turnover", "volume", "pre_close_price", 
                                             "open_interest", "settlement_price", "change_rate", 
                                             "pre_settlement_price"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("upper_limit_price", "limit_up"),
                                     ("lower_limit_price", "limit_down"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("settlement_price", "settlement"),
                                     ("pre_settlement_price", "pre_settlement")
                                     ]
        
        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_up"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_down"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["settlement"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_settlement"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["data_time"] = ctp_data_time_combine

        context.msg_clear_columns = ["action_date"]

        self.client_context = context

class HKSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "sseMktdt04Stream"
        self.sub_options = {"column_filter":["ask_price", "ask_volume", "bid_price", 
                                             "bid_volume", "unified_code", "data_time", 
                                             "open_price", "close_price", "high_price", 
                                             "low_price", "last_price", "turnover", 
                                             "volume", "pre_close_price", "change_rate",
                                             "ticker_status"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("ticker_status", "status")
                                     ]
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)

        context.msg_column_transformer["change_rate"] = functools.partial(self.round_number, ndigits=4)

        self.client_context = context

class SpotSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "spotStream"
        self.sub_options = {"column_filter":["data_time", "ask_price", "ask_volume", 
                                             "bid_price", "bid_volume", "unified_code", 
                                             "open_price", "close_price", "high_price", 
                                             "low_price", "last_price", "upper_limit_price", 
                                             "lower_limit_price", "turnover", "volume", 
                                             "pre_close_price", "settlement_price", "change_rate", 
                                             "pre_settlement_price"]}
        
        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("open_price", "open"),
                                     ("close_price", "close"),
                                     ("high_price", "high"),
                                     ("low_price", "low"),
                                     ("last_price", "last"),
                                     ("upper_limit_price", "limit_up"),
                                     ("lower_limit_price", "limit_down"),
                                     ("turnover", "total_turnover"),
                                     ("pre_close_price", "pre_close"),
                                     ("ask_price", "asks"),
                                     ("ask_volume", "ask_vols"),
                                     ("bid_price", "bids"),
                                     ("bid_volume", "bid_vols"),
                                     ("settlement_price", "settlement"),
                                     ("pre_settlement_price", "pre_settlement")
                                     ]
        
        context.msg_column_transformer["open"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["high"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["low"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["last"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_up"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["limit_down"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["total_turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["pre_close"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["asks"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["bids"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["settlement"] = functools.partial(self.round_number, ndigits=4)
        context.msg_column_transformer["pre_settlement"] = functools.partial(self.round_number, ndigits=4)

        self.client_context = context



class TradeSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpTradeStream"
        self.sub_options = {"column_filter":["unified_code", "exchange_id", 
                                             "channel_no", "trade_seq", "trade_date", 
                                             "data_time", "price", "volume", "turnover", 
                                             "bid_no", "ask_no", "trade_flag", "ticker"]}

        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("ask_no", "sell_no"),
                                     ("bid_no", "buy_no"),
                                     ("ticker", "trade_code")]

        context.msg_column_transformer["turnover"] = functools.partial(self.round_number, ndigits=3)
        context.msg_column_transformer["price"] = functools.partial(self.round_number, ndigits=4)
        self.client_context = context

class EntrustSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "xtpEntrustStream"
        self.sub_options = {"column_filter":["unified_code", "exchange_id", 
                                             "channel_no", "entrust_seq", "trade_date", 
                                             "data_time", "price", "volume", "order_no", 
                                             "order_type", "side", "ticker"]}

        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter

        context.msg_column_rename = [("ticker", "trade_code")]

        context.msg_column_transformer["price"] = functools.partial(self.round_number, ndigits=4)
        self.client_context = context

class TestSubTopic(QuoteSubscribeTopic):
    def  __init__(self, topic:str):
        self.topic = topic
        self.table_name = "spotStream"
        self.sub_options = {"column_filter":["insert_time", "data_time", "unified_code", "last_price"]}

        context = SubClientLocalContext()
        context.msg_adapter = msg_default_adapter
        context.msg_column_rename = [("data_time", "data_time_rename"),
                                     ("data_time", "data_time_rename2"),
                                     ("", "fly1")]
        context.msg_column_transformer["last_price"] = functools.partial(self.round_number, ndigits=1)
        context.msg_column_transformer["data_time_rename2"] = 3.14159
        context.msg_column_transformer["fly1"] = "str_fly1"
        context.msg_clear_columns = {"insert_time"}
        self.client_context = context
