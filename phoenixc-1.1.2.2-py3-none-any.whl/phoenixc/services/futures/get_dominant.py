"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import future_pb2, future_pb2_grpc
from phoenixc.services.basic import Basic


class GetDominant(Basic):
    def get_dominant(self, underlying_symbol, start_date=None, end_date=None):
        """获取某一期货品种一段时间的主力合约列表
        :param underlying_symbol:期货合约品种，例如沪深 300 股指期货为'IF'
        :param start_date:开始日期，默认为期货品种最早上市日期后一交易日,YYYY-MM-DD (Default value = None)
        :param end_date:结束日期，默认为当前日期,YYYY-MM-DD (Default value = None)
        :return:Pandas.Series，主力合约代码列表
        """
        self.is_initialized(init_instance.metadata)
        client = future_pb2_grpc.FutureServiceStub(init_instance.channel)
        if start_date is not None:
            start_date = self.check_date(start_date)
        if end_date is not None:
            end_date = self.check_date(end_date)
        response = client.get_dominant(
            future_pb2.ReqGetDominant(underlying_symbol=underlying_symbol, start_date=start_date, end_date=end_date), metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            response_df.set_index("trade_date", inplace=True)
            return response_df["unified_code"]
