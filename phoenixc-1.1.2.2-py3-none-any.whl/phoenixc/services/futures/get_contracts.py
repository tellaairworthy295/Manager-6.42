"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import future_pb2, future_pb2_grpc
from phoenixc.services.basic import Basic


class GetContracts(Basic):
    def get_contracts(self, underlying_symbol, date=None):
        """获取某一期货品种在某日期的可交易合约 unified_code 列表
        :param underlying_symbol:期货合约品种，例如沪深 300 股指期货为'IF'
        :param date:查询日期，默认为当日,YYYY-MM-DD (Default value = None)
        :return:str list - 可交易的 unified_code list
        """
        self.is_initialized(init_instance.metadata)
        client = future_pb2_grpc.FutureServiceStub(init_instance.channel)
        if date is not None:
            date = self.check_date(date)
        response = client.get_contracts(
            future_pb2.ReqGetContracts(underlying_symbol=underlying_symbol, date=date), metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            return list(response_dict.values())[0]
