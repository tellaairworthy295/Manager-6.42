"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import future_pb2, future_pb2_grpc
from phoenixc.services.basic import Basic


class GetBasis(Basic):
    def get_basis(self, unified_code, start_date=None, end_date=None):
        """获取股指期货每日升贴水数据(仅支持日频)
        :param unified_code:期货合约代码
        :param start_date:开始日期，YYYY-MM-DD (Default value = None)
        :param end_date:结束日期，YYYY-MM-DD (Default value = None) 两个日期均不传时默认返回最近三个月数据
        :return:pandas multi-index DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = future_pb2_grpc.FutureServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        if start_date is not None:
            start_date = self.check_date(start_date)
        if end_date is not None:
            end_date = self.check_date(end_date)
        response = client.get_basis(
            future_pb2.ReqGetBasis(unified_code=unified_code, start_date=start_date, end_date=end_date), metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            result_sorted = response_df.sort_values(by=["unified_code", "trade_date"])
            result_final = result_sorted.set_index(["unified_code", "trade_date"], drop=True)
            return result_final
