"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


class Tick:
    def __init__(self, d):
        self.__dict__ = d

    def __repr__(self):
        return f"Tick({self.__dict__})"


def current_snapshot(unified_code, market="cn"):
    """
    :param unified_code:合约代码,String/List格式
    :param market:地区代码,如 "cn" (Default value = "cn")
    :return:Tick Object或Tick Object列表
    """
    Basic().is_initialized(init_instance.metadata)
    client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
    unified_code, len_unified_code = Basic().format_unified_code(unified_code)
    response = client.current_snapshot(
        price_pb2.ReqCurrentSnapshotParams(unified_code=unified_code, market=market),
        metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        result_list = []
        field_name, columns_list, date_columns_list = Basic().get_data_list(response.DESCRIPTOR.fields[0])
        response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
        if len(date_columns_list) != 0:
            for i in date_columns_list:
                response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)  # 处理日期格式
                response_df[i] = response_df[i].dt.floor('ms')
        [result_list.append(Tick(response_df.iloc[j].to_dict())) for j in range(len(response_df))]
        if len_unified_code == 1:
            return result_list[0]
        return result_list
