"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import index_pb2, index_pb2_grpc
from phoenixc.services.basic import Basic


class IndexWeights(Basic):
    def index_weights(self, unified_code, date=None):
        """获取某一指数的历史构成以及权重
        :param unified_code:指数代码,String格式
        :param date:查询日期，默认为最新记录日期,YYYY-MM-DD (Default value = None)
        :return:pandas Series，每只股票在指数中的构成权重。
        """
        self.is_initialized(init_instance.metadata)
        client = index_pb2_grpc.IndexServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        if date is not None:
            date = self.check_date(date)
        response = client.index_weights(
            index_pb2.ReqIndexWeightsParam(unified_code=unified_code, date=date), metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            response_df.set_index("unified_code", inplace=True)
            return response_df["weight"]
