"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import index_pb2, index_pb2_grpc
from phoenixc.services.basic import Basic


class IndexComponents(Basic):
    def index_components(self, unified_code, start_date=None, end_date=None, date=None):
        """获取指数成分股列表
        :param unified_code:指数代码,String格式
        :param date:查询日期，默认为最新记录日期,YYYY-MM-DD (Default value = None)
        :param start_date:指定开始日期，不能和 date 同时指定,YYYY-MM-DD
        :param end_date:指定结束日期, 需和 start_date 同时指定并且应当不小于开始日期,YYYY-MM-DD
        :return:构成该指数股票的 unified_code list
        """
        self.is_initialized(init_instance.metadata)
        client = index_pb2_grpc.IndexServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        if date and (start_date or end_date):
            raise ValueError("date cannot be input together with start_date or end_date")
        elif (start_date and not end_date) or (end_date and not start_date):
            raise ValueError("start_date and end_date need to be applied together")
        if date:
            date = self.check_date(date)
        if start_date:
            start_date = self.check_date(start_date)
            end_date = self.check_date(end_date)
        response = client.index_components(
            index_pb2.ReqIndexComponentsParam(unified_code=unified_code, date=date, start_date=start_date, end_date=end_date),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if date or (date is None and start_date is None and end_date is None):
                return response_df.stock_unified_code.tolist()
            else:
                if len(date_columns_list) != 0:
                    for i in date_columns_list:
                        response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                        response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
                return response_df.groupby("data_date")["stock_unified_code"].apply(list).to_dict()
