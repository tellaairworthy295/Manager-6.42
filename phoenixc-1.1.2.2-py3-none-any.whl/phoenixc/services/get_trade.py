"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import tick_pb2, tick_pb2_grpc
from phoenixc.common import common_pb2
from phoenixc.services.basic import Basic
import io


class Trade(Basic):
    def get_trade(self, unified_code, start_date=None, end_date=None, time_slice=None, market='cn'):
        """获取level2数据中指定标的的逐笔成交数据，标的范围包括：个股、ETF、可转债、公司债、回购等
        :param unified_code:合约代码,String/List格式
        :param start_date:开始时间,YYYY-MM-DD
        :param end_date:结束时间,YYYY-MM-DD
        :param time_slice:开始和结束时间段,String格式:"HH:MM:SS.sss,HH:MM:SS.sss",默认返回全天数据 (Default value = None)
        :param market:地区代码,如 "cn" (Default value = "cn")
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        if bool(start_date) or bool(end_date):
            if start_date is not None:
                start_date = self.check_date(start_date)
            if end_date is not None:
                end_date = self.check_date(end_date)
        else:
            raise ValueError("'start_date': {} and 'end_date': {}, at least one non empty, format: 'YYYY-MM-DD'".format(start_date, end_date))
        unified_code, _ = self.format_unified_code(unified_code)
        time_slice = self.format_time_slice(time_slice)
        stub = tick_pb2_grpc.TickServiceStub(init_instance.channel)
        req = tick_pb2.ReqGetTradeParams(unified_code=unified_code, start_date=start_date, end_date=end_date,
                                         time_slice=time_slice, market=market, data_type="DATAFRAME")
        data = stub.get_trade(req, metadata=init_instance.metadata)
        if req.data_type == common_pb2.DATAFRAME:
            trade_df = pd.read_parquet(io.BytesIO(data.trade_dataframe))
            if len(trade_df) == 0:
                return None
            else:
                return trade_df
        else:
            data_dict = json_format_custom.json_format.MessageToDict(message=data, preserving_proto_field_name=True)
            if len(data_dict) == 0:
                return None
            else:
                field_name = None
                columns_list = []
                date_columns_list = []
                for field in data.DESCRIPTOR.fields:
                    if field.name[-7:] == "message":
                        field_name, columns_list, date_columns_list = self.get_data_list(field)
                        break
                trade_df_all = pd.DataFrame(data_dict[field_name], columns=columns_list)
                if len(date_columns_list) != 0:
                    for i in date_columns_list:
                        trade_df_all[i] = pd.to_datetime(trade_df_all[i], format="ISO8601").dt.tz_localize(None)
                        trade_df_all[i] = trade_df_all[i].dt.floor('ms')  # 取到毫秒
                return trade_df_all
