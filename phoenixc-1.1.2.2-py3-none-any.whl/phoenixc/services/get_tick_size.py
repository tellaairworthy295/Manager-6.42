"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


class GetTickSize(Basic):
    def get_tick_size(self, unified_code):
        """查询申报价格最小变动单位
        :param unified_code:合约代码,String/List格式
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        unified_code,_ = self.format_unified_code(unified_code)
        client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
        response = client.get_tick_size(
            price_pb2.ReqGetTickSizeParam(unified_code=unified_code),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            result = response_df.set_index(["unified_code"], drop=True)
            return result["tick_size"]
