"""
-*- coding: utf-8 -*-
@Time : 2024
"""
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import calendar_pb2, calendar_pb2_grpc
from phoenixc.services.basic import Basic


def get_trade_time(exchange, major_type, minor_type=None):
    """查询交易时间
    :param exchange:交易所代码
    :param major_type:一级品种类型
    :param minor_type: 二级品种类型(Default value = None)
    :return:返回当前日期有效的交易时间 trading_hours: 格式string:交易星期,多个[交易时段类别，xx:xx-xx:xx]
                          交易星期:1-7表示周-至周日
                          交易时段类别:
                                    1:主要交易时段
                                    2:主要集合竞价时段
                                    3:主要盘后交易时段
                          示例："1,2,3,4,5,[2,09:15-09:25][1,09:30-11:30][1,13:00-15 :00]"
    """
    Basic().is_initialized(init_instance.metadata)
    client = calendar_pb2_grpc.CalendarServiceStub(init_instance.channel)
    response = client.get_trading_time(
        calendar_pb2.ReqGetTradeTimeParams(exchange=exchange, major_type=major_type, minor_type=minor_type), metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        return response_dict["trade_time"]
