"""
-*- coding: utf-8 -*-
@Time : 2024
"""
"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
import numpy as np
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import factor_pb2, factor_pb2_grpc
from phoenixc.common import common_pb2
from phoenixc.services.basic import Basic
import io
import time


class GetFactor(Basic):
    def get_factor(self, unified_code, factor, start_date=None, end_date=None, frequency="d", adjust_type="none", universe=None):
        """默认快速返回给定的unified_code距离当日最近的因子数据,给定日期返回两日期之间的因子数据
        :param unified_code:合约代码,String/List格式
        :param factor:因子名称,String/List格式,当前仅支持["dif","dea","macd","market_cap", "market_cap_2"]
        :param start_date:开始日期,"YYYY-MM-DD HH:MM:SS" (Default value = None) 如使用开始日期，则必填结束日期,至少填写"YYYY-MM-DD"
        :param end_date:结束日期,"YYYY-MM-DD HH:MM:SS" (Default value = None) 若使用结束日期，则开始日期必填,至少填写"YYYY-MM-DD"
        :param frequency:频率,String/List格式,默认为"d"日线频率,其它可选值：1m、5m、10m、15m、30m、60m、120m和240m
                       （注意：分钟频数据，如果开始和结束时间均为None，返回最新一个交易日的全天数据）
        :param adjust_type:权息修复方案,不复权'none',前复权'pre'，后复权'post' (Default value = "none")
        :param universe:股票池,默认为 None,全市场,目前仅支持全市场
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = factor_pb2_grpc.FactorServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        factor_str = self.format_param(factor)
        frequency = self.format_param(frequency)
        if start_date is not None:
            start_date = self.check_time(start_date)
            if end_date is None:
                raise ValueError(
                    "invalid date: {}, If using a start_date, the end_date must be filled in".format(end_date))
        if end_date is not None:
            end_date = self.check_time(end_date)
            if start_date is None:
                raise ValueError(
                    "invalid date: {}, If using a end_date, the start_date must be filled in".format(start_date))
        req = factor_pb2.ReqGetFactorParams(unified_code=unified_code, factor=factor_str, start_date=start_date,
                                            end_date=end_date, frequency=frequency, adjust_type=adjust_type,
                                            universe=universe, data_type="DATAFRAME")
        data = client.get_factor(req, metadata=init_instance.metadata)
        if req.data_type == common_pb2.DATAFRAME:
            factor_df = pd.read_parquet(io.BytesIO(data.factor_dataframe))
            if len(factor_df) == 0:
                return None
        else:
            data_dict = json_format_custom.json_format.MessageToDict(message=data, preserving_proto_field_name=True)
            if len(data_dict) == 0:
                return None
            else:
                field_name = None
                columns_list = []
                date_columns_list = []
                for field in data.DESCRIPTOR.fields:
                    if field.name[-7:] == "message":
                        field_name, columns_list, date_columns_list = self.get_data_list(field)
                        break
                factor_df = pd.DataFrame(data_dict[field_name], columns=columns_list)
                if len(date_columns_list) != 0:
                    for i in date_columns_list:
                        factor_df[i] = pd.to_datetime(factor_df[i], format="ISO8601").dt.tz_localize(None)
                        factor_df[i] = factor_df[i].dt.floor('ms')  # 取到毫秒
        result = pd.pivot(factor_df, values="factor_value", index=["unified_code", "date", "frequency"],
                          columns=["factor_code"])
        exist_columns = list(result.columns.values)
        no_exist_columns = [x for x in factor if x not in  exist_columns]
        for column_name in no_exist_columns:
            result[column_name] = np.nan
            
        result.columns = result.columns.values
        result.reset_index(inplace=True)
        result_sorted = result.sort_values(by=["unified_code", "date"])
        result_final = result_sorted.set_index(["unified_code", "date"], drop=True)
        return result_final