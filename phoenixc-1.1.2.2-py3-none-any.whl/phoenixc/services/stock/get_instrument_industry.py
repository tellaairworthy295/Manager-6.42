"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import industry_pb2, industry_pb2_grpc
from phoenixc.services.basic import Basic

class GetInstrumentIndustry(Basic):
    def get_instrument_industry(self, unified_code, source=5, date=None, level=1):
        """
        获取股票的指定行业分类
        :param unified_code: 股票合约代码
        :param source: 分类依据。1=中信行业；5=申万行业分类（2021版）。默认为5
        :param date: 日期,YYYY-MM-DD (Default value = None)，默认为当前最新日期
        :param level: 行业分类级别，共三级，默认返回一级分类。参数 0,1,2,3 一一对应，其中 0 返回三级分类完整情况.
        :return: pandas DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = industry_pb2_grpc.IndustryServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        if date is not None:
            date = self.check_date(date)
        response = client.get_instrument_industry(
            industry_pb2.ReqGetInstrumentIndustryParam(unified_code=unified_code, source=source, date=date),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            result_final = response_df.set_index("unified_code", drop=True)
            if level == 0:
                return result_final
            elif level == 1:
                return result_final[["first_industry_code", "first_industry_name"]]
            elif level == 2:
                return result_final[["second_industry_code", "second_industry_name"]]
            elif level == 3:
                return result_final[["third_industry_code", "third_industry_name"]]