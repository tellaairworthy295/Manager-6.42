"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


class GetSplit(Basic):
    def get_split(self, unified_code, start_date=None, end_date=None, market="cn"):
        """获取某只股票在一段时间内的拆分情况,如未指定日期，则默认所有
        :param unified_code:合约代码,String/List格式
        :param start_date:开始日期,YYYY-MM-DD (Default value = None)
        :param end_date:结束日期,YYYY-MM-DD (Default value = None)
        :param market:市场,目前仅支持"cn"
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
        unified_code, _ = self.format_unified_code(unified_code)
        if start_date is not None:
            start_date = self.check_date(start_date)
        if end_date is not None:
            end_date = self.check_date(end_date)
        response = client.get_split(
            price_pb2.ReqGetSplitParam(unified_code=unified_code, start_date=start_date, end_date=end_date, market=market),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            result_sorted = response_df.sort_values(by=["unified_code", "ex_dividend_date"])
            result_final = result_sorted.set_index(["unified_code", "ex_dividend_date"], drop=True)
            return result_final
