"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import industry_pb2, industry_pb2_grpc
from phoenixc.services.basic import Basic

class GetIndustry(Basic):
    def get_industry(self, industry, source=5, date=None):
        """
        获取某行业的股票列表
        :param industry: 可传入行业名称、行业指数代码或者行业代号
        :param source: 分类依据。1=中信行业；5=申万行业分类（2021版）。默认为5
        :param date: 日期,YYYY-MM-DD (Default value = None)，默认为当前最新日期
        :return: list
        """
        self.is_initialized(init_instance.metadata)
        client = industry_pb2_grpc.IndustryServiceStub(init_instance.channel)
        if date is not None:
            date = self.check_date(date)
        response = client.get_industry(
            industry_pb2.ReqGetIndustryParam(industry=industry, source=source, date=date),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            return list(response_dict.values())[0]
        
    def get_industry_index(self, industry_code, source=5, level=1):
        """
        获取某行业的股票列表
        :param industry_code: 行业指数代码或者行业代号
        :param source: 分类依据。1=中信行业；5=申万行业分类（2021版）。默认为5
        :param level: 行业级别，默认为一级
        :return: list
        """
        self.is_initialized(init_instance.metadata)
        industry_codes = self.format_param(industry_code)
        client = industry_pb2_grpc.IndustryServiceStub(init_instance.channel)
        response = client.get_industry_index(
            industry_pb2.ReqGetIndustryIndexParam(industry_code=industry_codes, source=source, level=level),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            #response_df.set_index(["industry_code"], inplace=True)
            return response_df

