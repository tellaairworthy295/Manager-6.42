"""
-*- coding: utf-8 -*-
@Time : 2025
"""
"""
-*- coding: utf-8 -*-
@Time : 2025
"""
import datetime
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


def get_st_days(unified_code, start_date, end_date=None):
    """查询股票特别处理的日期（交易日）
    :param unified_code:合约代码,String/List格式
    :param start_date:开始日期,YYYY-MM-DD,必填
    :param end_date:结束日期,YYYY-MM-DD,不必填
    :return: dict
    """
    Basic().is_initialized(init_instance.metadata)
    unified_code, _ = Basic.format_unified_code(unified_code)
    start_date = Basic().check_date(start_date)
    if end_date is not None:
        end_date = Basic().check_date(end_date)
    client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
    response = client.get_st_days(
        price_pb2.ReqGetStDaysParam(unified_code=unified_code, start_date=start_date, end_date=end_date), metadata=init_instance.metadata)
    response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
    if len(response_dict) == 0:
        return None
    else:
        field_name, columns_list, date_columns_list = Basic.get_data_list(response.DESCRIPTOR.fields[0])
        response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
        response_df["date"] = list(map(Basic().change_date, response_df["date"]))
        result_dict = response_df.groupby("unified_code")["date"].apply(list).to_dict()
        return result_dict