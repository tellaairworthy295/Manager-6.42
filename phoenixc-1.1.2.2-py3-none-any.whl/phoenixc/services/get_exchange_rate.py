"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic

class GetExchangeRate(Basic):
    def get_exchange_rate(self, start_date, end_date):
        """
        获取指定时间段的汇率信息
        :param start_date: 开始日期，YYYY-MM-DD
        :param end_date: 结束日期，YYYY-MM-DD
        :return: pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
        if start_date is not None:
            start_date = self.check_date(start_date)
        if end_date is not None:
            end_date = self.check_date(end_date)
        response = client.get_exchange_rate(
            price_pb2.ReqGetExchangeRateParam(start_date=start_date, end_date=end_date), metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name, columns_list, date_columns_list = self.get_data_list(response.DESCRIPTOR.fields[0])
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            response_df.set_index("trade_date", inplace=True)
            return response_df