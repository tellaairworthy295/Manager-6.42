"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import instruments_pb2, instruments_pb2_grpc
from phoenixc.common import common_pb2
from phoenixc.services.basic import Basic
import io


class AllInstruments(Basic):
    def all_instruments(self, type, market="cn", exchange=None, date=None):
        """查询场内/场外合约信息
        :param type:标的类型
        :param market:地区代码,如 "cn" (Default value = "cn")
        :param exchange:交易所列表,如 ["SZ"] (Default value = None)
        :param date: (Default value = None)
        :return:Dataframe
        """
        self.is_initialized(init_instance.metadata)
        if date is not None:
            date = self.check_date(date)
        type_list = ["CS", "ETF", "LOF", "INDEX", "FUTURE", "SPOT", "OPTION", "CONVERTIBLE", "REPO", "BOND", "OF"]
        if type.upper() not in type_list:
            raise ValueError("invalid type: {}, chose any in {}, Case-insensitive".format(type, type_list))
        if type.upper() in ["ETF", "LOF", "OF"] and date is None:
            raise ValueError("require date when type is {}".format(type))
        stub = instruments_pb2_grpc.InstrumentServiceStub(init_instance.channel)
        req = instruments_pb2.ReqAllInstrumentsParams(type=type, market=market, exchange=exchange, date=date,
                                                      data_type="DATAFRAME")
        data = stub.all_instruments(req, metadata=init_instance.metadata)

        if req.data_type == common_pb2.DATAFRAME:
            all_instruments_df = pd.read_parquet(io.BytesIO(data.basic_dataframe))
            if len(all_instruments_df) == 0:
                return None
            else:
                return all_instruments_df
        else:
            data_dict = json_format_custom.json_format.MessageToDict(message=data, preserving_proto_field_name=True)
            if len(data_dict) == 0:
                return None
            else:
                field_name = None
                columns_list = []
                date_columns_list = []
                for field in data.DESCRIPTOR.fields:
                    if len(getattr(data, field.name)) != 0:
                        field_name, columns_list, date_columns_list = self.get_data_list(field)
                        break
                all_instruments_df = pd.DataFrame(data_dict[field_name], columns=columns_list)
                if len(date_columns_list) != 0:
                    for i in date_columns_list:
                        all_instruments_df[i] = pd.to_datetime(all_instruments_df[i], format="ISO8601").dt.tz_localize(
                            None)
                        all_instruments_df[i] = all_instruments_df[i].dt.floor('ms')  # 取到毫秒
                return all_instruments_df
