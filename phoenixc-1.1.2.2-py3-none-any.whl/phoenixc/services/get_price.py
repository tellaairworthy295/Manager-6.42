"""
-*- coding: utf-8 -*-
@Time : 2024
"""
import pandas as pd
from phoenixc.services import json_format_custom
from phoenixc import init_instance
from phoenixc.common import price_pb2, price_pb2_grpc
from phoenixc.services.basic import Basic


class GetPrice(Basic):
    def get_price(self, unified_code, start_date, end_date, frequency="1d", adjust_type="pre", market="cn", time_slice=None):
        """获取指定合约或合约列表的历史数据(包含起止日期,周线、日线或分钟线),目前仅支持中国市场的股票、期货、ETF、常见指数和上金所现货的行情数据,如黄金、铂金和白银产品
        :param unified_code:合约代码,String/List格式
        :param start_date:开始日期,YYYY-MM-DD
        :param end_date:结束日期,YYYY-MM-DD
        :param frequency:历史数据的频率,默认为日线 (Default value = "1d")
        :param adjust_type:权息修复方案,不复权'none',前复权'pre'，后复权'post' (Default value = "pre")
        :param market:地区代码,如 'cn' (Default value = "cn")
        :param time_slice:tuple(str,str)/tuple(datetime.time,datetime.time)开始结束时间点用于切分数据,默认返回当天所有数据 (Default value = None)
        :return:pandas.DataFrame
        """
        self.is_initialized(init_instance.metadata)
        start_date = self.check_date(start_date)
        end_date = self.check_date(end_date)
        unified_code, _ = self.format_unified_code(unified_code)
        time_slice = self.format_time_slice(time_slice)
        client = price_pb2_grpc.PriceServiceStub(init_instance.channel)
        response = client.get_price(
            price_pb2.ReqPriceParams(unified_code=unified_code, start_date=start_date, end_date=end_date,
                                     frequency=frequency, adjust_type=adjust_type, market=market, time_slice=time_slice),
            metadata=init_instance.metadata)
        response_dict = json_format_custom.json_format.MessageToDict(response, preserving_proto_field_name=True)
        if len(response_dict) == 0:
            return None
        else:
            field_name = None
            columns_list = []
            date_columns_list = []
            for field in response.DESCRIPTOR.fields:
                if len(getattr(response, field.name)) != 0:
                    field_name, columns_list, date_columns_list = self.get_data_list(field)
                    break
            response_df = pd.DataFrame(response_dict[field_name], columns=columns_list)
            if len(date_columns_list) != 0:
                for i in date_columns_list:
                    response_df[i] = pd.to_datetime(response_df[i], format="ISO8601").dt.tz_localize(None)  # 处理日期格式
                    response_df[i] = response_df[i].dt.floor('ms')  # 取到毫秒
            if response_df["data_time"].isna().all():
                time_or_date = "trading_date"
            else:
                time_or_date = "data_time"
            result_sorted = response_df.sort_values(by=["unified_code", time_or_date])
            result_final = result_sorted.set_index(["unified_code", time_or_date], drop=True)
            return result_final
